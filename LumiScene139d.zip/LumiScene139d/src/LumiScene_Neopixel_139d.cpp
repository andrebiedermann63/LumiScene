/*
120
Bedienung Lichtsensor vereinfacht
Setup aufgeräumt
Ausgänge für Beleuchtung Aktiv
Funktion Einschaltzein ersetzt durch Array EinschaltZeit
Parameterseiten und Legenden Zusammengenommen
Legenden verbessert, sodass im Handbuch Teile wegfallen können
130
Legende updaten
Banner verbessern
131
HTML Namen einkürzen
CSS aufräumen
132
Laden der Webseite optimieren
133
Auslöser anzeigen.
134
tg-1692 --> tg1
onmousedown --> onclick
DeviceAnzahlBlinken
ButtonFarben anpassen
Abstände auf Optionsseite optimieren (Import Export)
Anzahl LEDs gesamt Feedback
Anstände Optionsseite optimiert
Legendentexte überarbeiten (teilweise)
135
Table neu formatieren
Taste für LED Anzeigen
Button-Breiten angepasst
136
Vorbereitung für Sprachumschaltung
Optionsseiten umbauen
Optionen und Auslöser umbenannt in Settings1 und Settings2
Kalibrierprofil zu Settings 2 verschoben
Buttons für Sprachumstellung implementiert.
Infotabellen vertikal aufgetielt mit horizontalen Trennlinien
Kalibrierung in Gamma umbenennen
137
Sprachumstellung auspflegen
Versionsanzeige auf Optionsseite1
Legendentexte überarbeiten
Konstanten nach PROGMEM verschieben.
Debugg Auslöser
Informationen der Eingänge auf Optionsseite 2
Erstanlauf debuggen: Verisons konstatnte PROGMEM entfernt
PROGMEM von allen Konstanten entfernt.
SD-Karte testen
EepromAdressen als const anstatt Variable definiert.
138
String htmlPage; als lokale Variable in der Funktion definiert.
Optionen 1: 1. Blaue Trennline entfernt
139


IN PROGRESS
Auslösers prüfen und umprogrammieren

TODO
Ersetze
WriteConfigSd durch ExportConfigToSd
Ersetze ReadConfigSd durch ImportConfigFromSD
*/

/*
██████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████   ████████     ██████    █████   ███      ███           ██████████████████████████████████████████
████████   ███   ███   ████   ███  █   ███   █   ████   █████   ██████████████████████████████████████████████
███████   ████████   ████████   █   █   ██   ██   ███████████   ██████████████████████████████████████████████
███████   ████████   ████████   █   ██   █   ████   █████████   ██████████████████████████████████████████████
███████   ████████   ████████   █   ███  █   ███████   ██████   ██████████████████████████████████████████████
████████   ███   ███   █████   ██   ████  █  █   ████   █████   ██████████████████████████████████████████████
██████████     ███████     ██████   ██████   ███      ███████   ██████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include "SPI.h"
#include <Adafruit_NeoPixel.h>
#include <EEPROM.h>
#include <SD.h>

#define Trennzeichen ';'
char ssid[30];                     // SSID für Wireless
const char *password = "12345678"; // Passwort für Wireless

ESP8266WebServer server(80);

const uint8_t VersionAktuell = 139;                     // Aktuelle Version für Versionscheck
const uint8_t VersionMindest = 120;                     // Mindest Versionsstand der kompatibel ist bezüglich Parametern.
const uint8_t AnzahlLedMax = 39;                        // Maximale Anzahl LEDs
const uint8_t AnzahlTV = 3;                             // Anzahl der verschiedenen TV-Kanäle
const uint8_t HelligkeitMax = 2;                        // Höchste Helligkeitsstufe (Anzahl Helligkeitsstufen - 1)
const uint8_t HelligkeitVal[] = {140, 180, 255};        // Value Wert für Helligkeitsstufen
const uint8_t HelligkeitValWackel[] = {100, 120, 170};  // Value Wert für Helligkeitsstufen für Wackelkontakte
const uint8_t DeviceNrMax = 99;                         // Grösste Device-Nr
const uint8_t AnzahlPhasenMax = 8;                      // Maximale Anzahl Phasen pro Szene
const uint8_t AnzahlByteProPhase = 2;                   // Anzahl Parameter pro Phase (Farbe & Effekt kombiniert / Helligkeit & Zeitwahl kombiniert)
const uint8_t AnzahlByteProSzene = 1;                   // Anzahl Parameter pro Szene (ProgAnzahl)
const uint8_t AnzahlSzenarios = 6;                      // Anzahl Speichersets für Szenarien
const uint8_t Gesamthelligkeit = 100;                   // Gesamthelligkeit der LED-Kette
const uint8_t Starterkennung = 99;                      // Wert für Starterkennung
const int Buzzer = 5;                                   // Ansteuerung Piepser: Entrpricht Pin D1

const uint8_t EepromAnzahlEinzelwerte = 20;             // Reservierter Bereich für Einzelwerte
const uint8_t Zyklus = 50;                              // Bearbeitungszyklus in ms
const unsigned int Faktor = 1000 / Zyklus;              // entspricht 1000 Milisekunden / Zykluszeit
const uint8_t dataPinWS2812 =          D8;              // LED-Kette für WS2812 Daten Pin an D8 am ESP8266
const uint8_t dataPinPL9823 =          D7;              // LED-Kette für PL9823 Daten Pin an D7 am ESP8266
const uint8_t PirSensor =              D6;              // PIR Sensor oder Radar Sensor
const uint8_t Kontakt =                D5;              // Kontakt mechanisch (Taster, Relais etc.)
const uint8_t BeleuchtungAktiv1 =      D2;              // Beleuchtung aktiv = 1
const uint8_t BeleuchtungAktiv0 =      D3;              // Beleuchtung aktiv = 0
const uint8_t Photowiderstand =        A0;              // Phptowiderstand
const uint32_t HueSpektrum = 65535;                     // Gesamtes Hue Spektrum
const uint8_t UintMax = 255;                            // Wert 255
const int LDRGrenze[] = {INT_MAX, 70, 100, 130, 160, 200, 300}; // Schaltgrenzen für LDR
// const int LDRHysterese[] = {0, 70, 100, 130, 160, 200, 300}; // Hysterese für LDR  ??? alte werte
const int LDRHysterese[] = {0, 50, 700, 100, 120, 150, 200};    // Hysterese für LDR
const uint8_t AusloeserEinflussMax = 2;                         // Maximalwert Pir Einfluss
const uint8_t EinschaltTimerMax = 12;                           // Maximalwert Pir Einfluss
const uint8_t GammaprofilMax = 1;                           // Maximalwert Kalibreriprofil-Auswahl
const unsigned long EinschaltZeit[] = {0, 4, Faktor * 15, Faktor * 30, Faktor * 60, Faktor * 120, Faktor * 300, Faktor * 600, Faktor * 1200, Faktor * 1800, Faktor * 3600, Faktor *7200, Faktor * 10800};
// Anmerkung zu zweiten Wert = 4: 4 Zyklen um ev Wackelkontakte an Taster oder Kontakt zu überbrücken.

//■■  Farben Farbmanagement ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
const uint32_t HueRot = 0;           // Hue Rot
const uint32_t HueOrange = 6500;     // Hue Orange
const uint32_t HueGelb = 10000;      // Hue Gelb
const uint32_t HueLimette = 12500;   // Hue Limette
const uint32_t HueGruen = 18000;     // Hue Grün
const uint32_t HueTuerkis = 27000;   // Hue Türkis
const uint32_t HueCyan = 34000;      // Hue Cyan
const uint32_t HueBlau = 44000;      // Hue Blau
const uint32_t HueLila = 48000;      // Hue Lila
const uint32_t HueMagenta = 53000;   // Hue Magenta
const uint32_t HuePink = 57500;      // Hue Pink
const uint32_t HueKirschrot = 62000; // Hue Kirschrot

//■■  Weisstöne Farbmanagement ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
const float GammaRw = 1.0; // Gammawert Rot für PL9823
const float GammaGw = 1.0; // Gammawert Grün für PL9823
const float GammaBw = 1.3; // Gammawert Blau für PL9823

const uint32_t MaxRw[] = {206, 255}; // Maximalwert Rot für WS2812 (Kalibrierwerte für Profile C1 unbd C2)
const uint32_t MaxGw[] = {255, 194}; // Maximalwert Grün für WS2812 (Kalibrierwerte für Profile C1 unbd C2)
const uint32_t MaxBw[] = {154, 213}; // Maximalwert Blau für WS2812 (Kalibrierwerte für Profile C1 unbd C2)

const float GammaRp[] = {1.5, 1.0}; // Gammawert Rot für WS2812 (Kalibrierwerte für Profile C1 unbd C2)
const float GammaGp[] = {1.0, 1.0}; // Gammawert Grün für WS2812 (Kalibrierwerte für Profile C1 unbd C2)
const float GammaBp[] = {1.0, 1.0}; // Gammawert Blau für WS2812 (Kalibrierwerte für Profile C1 unbd C2)

const uint32_t MaxRp = 255; // Maximalwert Rot für PL9823
const uint32_t MaxGp = 244; // Maximalwert Grün für PL9823
const uint32_t MaxBp = 255; // Maximalwert Blau für PL9823

const uint32_t WarmweissHue[] = {13100, 7782};     // HUE Wert für Warmweiss (Kalibrierwerte für Profile C1 unbd C2)
const uint8_t WarmweissSat[] = {185, 150};         // SAT Wert für Warmweiss (Kalibrierwerte für Profile C1 unbd C2)

const uint32_t KaltweissHue[] = {29800, 38502};    // HUE Wert für Kaltweiss (Kalibrierwerte für Profile C1 unbd C2)
const uint8_t KaltweissSat[] = {110, 65};          // SAT Wert für Kaltweiss (Kalibrierwerte für Profile C1 unbd C2)

const uint32_t NeutralweissHue[] = {32100, 65535}; // HUE Wert für Kaltweiss (Kalibrierwerte für Profile C1 unbd C2)
const uint8_t NeutralweissSat[] = {40, 20};        // SAT Wert für Kaltweiss (Kalibrierwerte für Profile C1 unbd C2)

//■■  Leuchtstoff Effekt ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
const uint8_t NeonValHalbhell[] = {80, 90, 120}; // Jusierwerte für Dunkel, Mittel, Hell

const float NeonZeitHalbhellEinschaltMin = 0.0; // Minimale Wartezeit in s
const float NeonZeitHalbhellEinschaltMax = 0.2; // Maximale Wartezeit in s
const float NeonZeitImpulsEinschaltMin = 0.2;   // Minimale Wartezeit in s
const float NeonZeitImpulsEinschaltMax = 0.4;   // Maximale Wartezeit in s
const float NeonZeitHalbhellDauerMin = 0.5;     // Minimale Wartezeit in s
const float NeonZeitHalbhellDauerMax = 4.0;     // Maximale Wartezeit in s
const float NeonZeitImpulsDauerMin = 0.5;       // Minimale Wartezeit in s
const float NeonZeitImpulsDauerMax = 1.0;       // Maximale Wartezeit in s

const uint8_t FlackerZyklenMax = 10;                    // Maximale Anzahl Flackerzyklen Leuchtstoff
const uint8_t FlackerZyklenMin = 4;                     // Minimale Anzahl Flackerzyklen Leuchtstoff

//■■  Wackelkontakt Effekt ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
const float WK1PauseMin = 30;    // Minimale Wartezeit in s
const float WK1PauseMax = 60;    // Maximale Wartezeit in s
const uint8_t WK1ZyklenMin = 10; // Minimale Anzahl Wackelzyklen
const uint8_t WK1ZyklenMax = 40; // Maximale Anzahl Wackelzyklen

const float WK2PauseMin = 8;     // Minimale Wartezeit in s
const float WK2PauseMax = 15;    // Maximale Wartezeit in s
const uint8_t WK2ZyklenMin = 5;  // Minimale Anzahl Wackelzyklen
const uint8_t WK2ZyklenMax = 15; // Maximale Anzahl Wackelzyklen

const float WK3PauseMin = 1;     // Minimale Wartezeit in s
const float WK3PauseMax = 6;     // Maximale Wartezeit in s
const uint8_t WK3ZyklenMin = 3;  // Minimale Anzahl Wackelzyklen
const uint8_t WK3ZyklenMax = 30; // Maximale Anzahl Wackelzyklen

//■■  Feuer Effekt ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
const uint8_t FeuerSat[] = {200, 220, 255};         // Jusierwerte für Dunkel, Mittel, Hell

const uint8_t Feuer1ValMax[] = {130, 170, 255};     // Jusierwerte für Dunkel, Mittel, Hell
const uint8_t Feuer1ValMin[] = {90, 110, 150};      // Jusierwerte für Dunkel, Mittel, Hell
const float Feuer1DelayMin = 0.5;           // Minimale Wartezeit in s
const float Feuer1DelayMax = 4;             // Maximale Wartezeit in s

const uint8_t Feuer2ValMax[] = {130, 170, 255};     // Jusierwerte für Dunkel, Mittel, Hell
const uint8_t Feuer2ValMin[] = {50, 80, 110};       // Jusierwerte für Dunkel, Mittel, Hell
const float Feuer2DelayMin = 0.25;          // Minimale Wartezeit in s
const float Feuer2DelayMax = 1;             // Maximale Wartezeit in s

//■■  TV Effekt ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
//           Fernsehkanal:   TV1  TV2  TV3
const uint8_t ChanceNeu[] = {20, 40, 70};           // Chance für eine neue Farbe (%)
// C         hanceBleibt:   Rest zu 100%            // Chance für gleiche Farbe (%)

//            Fernsehkanal:   TV1  TV2  TV3
const uint8_t ChanceBunt[] = {0, 30, 50};           // Chance für eine satte Farbe (%)
// ChanceMatt:               Rest zu 100%           // Chance für eine matte Farbe (%)

const uint8_t SatBuntVon = 60;              // Zufallsbereich Bunt Minimalwert
const uint8_t SatBuntBis = 130;             // Zufallsbereich Bunt Maximalwert
const uint8_t SatMattVon = 0;               // Zufallsbereich Matt Minimalwert
const uint8_t SatMattBis = 50;              // Zufallsbereich Matt Maximalwert

const uint8_t ChanceShiftDirekt[] = {70, 50, 40};   // Chance für Gleiten zu neuer Farbe direkt (%)
const uint8_t ChanceShiftUmweg[] = {10, 10, 10};    // Chance für Gleiten zu neuer Farbe via Abdunklung (%)
//ChanceSprung:                    Rest zu 100%     // Chance für sofortigen Farbwechsel mit delay (%)

// Der reservierte Bereich für die Anzahl Einzelwerte ist über die Konstante "EepromAnzahlEinzelwerte" definiert.
const uint8_t EepromAddrDeviceNr = 0;           // Addresse für Device Nummer
const uint8_t EepromAddrAnzahlWS2812 = 1;       // Addresse für Anzahl WS2812
const uint8_t EepromAddrAnzahlPL9823 = 2;       // Addresse für Anzahl PL9823
const uint8_t EepromAddrAnzahlLED = 3;          // Addresse für Anzahl LEDs total
const uint8_t EepromAddrLDRLevel = 4;           // Addresse für Automode gemäss Helligkeit
const uint8_t EepromAddrVersion = 5;            // Addresse für Version
const uint8_t EepromAddrReserve = 6;            // Addresse Reserve
const uint8_t EepromAddrEinschaltIndex = 7;     // Addresse für EinschaltIndex
const uint8_t EepromAddrGammaprofil = 8;        // Addresse für Gammaprofil-Auswahl

//■■  WEB Ausgabe-Texte ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
const char* FarbTexte[] PROGMEM = {"Aus ", "Rot ", "Orange ", "Gelb ", "Limette ", "Grün ", "Türkis ", "Cyan ", "Blau ", "Lila ", "Magenta ", "Pink ", "Kirschrot ", "", "", "Wie-1 ", "Wie-2 ", "Wie-3 ", "Wie-4 ", "", "Warmweiss ", "Kaltweiss ", "Neutralweiss ", "", "", "Fernsehprogramm ruhig ", "Fernsehprogramm mittel ", "Fernsehprogramm lebhaft "};
const char* EffektTexte[] PROGMEM = {"konstant ", "Leuchtstoff Einschaltflackern ", "Leuchtstoff Dauerflackern ", "Feuer ruhiger ", "Feuer lebhafter ", "Wackelkontakt selten ", "Wackelkontakt mittel ", "Wackelkontakt oft "};
const char* ZeitTexte[] PROGMEM = {"0.1sek ", "0.2sek ", "0.5sek ", "1sek ", "2sek ", "3sek ", "5sek ", "10sek ", "20sek ", "60sek ", "0.5...1.5min ", "1...3min ", "2...4min ", "2.5...7.5min ", "3.5...10min ", "5...15min ", "7.5...22.5min ", "10...30min "};
const char* HelligkeitTexte[] PROGMEM = {"dunkel", "mittel", "hell"};
const char* GammaprofilTexte[] PROGMEM = {"Alt", "Neu"};
const char* AusloeserTexte[] PROGMEM = {"Deaktivert", "Solange Signal ansteht", "15 Sekunden verlängert", "30 Sekunden verlängert", "1 Minute verlängert", "2 Minuten verlängert", "5 Minuten verlängert", "10 Minuten verlängert", "20 Minuten verlängert", "1 Stunde verlängert", "2 Stunden verlängert", "3 Stunden verlängert"};
const char* AuslöserEinflussText PROGMEM = "Deaktivert";
const char* LichtsensorTexte[] PROGMEM = {"Deaktivert", "Auslösehelligkeit 6 (sehr hell)", "Auslösehelligkeit 5 (hell)", "Auslösehelligkeit 4 (mittel)", "Auslösehelligkeit 3 (mittel)", "Auslösehelligkeit 2 (dunkel)", "Auslösehelligkeit 1 (sehr dunkel)"};
/*
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
██   █████████   ███████  ████████        █████   ███████  ████████     █████   ████████         █    █████   ██████
███   ███████   ███████  █  ██████   ████   ███   ██████  █  ██████  ██   ███   ████████   ███████  █   ███   ██████
████   █████   ███████  ██   █████   ████   ███   █████  ██   █████  ███   ██   ████████   ███████   █   ██   ██████
█████   ███   ███████   ███   ████  █   ███████   ████   ███   ████      ████   ████████       ███   ██   █   ██████
██████   █   ███████       █   ███   ██   █████   ███       █   ███  ████   █   ████████   ███████   ███  █   ██████
███████     ███████   ███████   ██   ████   ███   ██   ███████   ██  █████  █   ████████   ███████   ████  █  ██████
████████   ███████   █████████   █   ██████   █   █   █████████   █    █   ██          █         █   ██████   ██████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
unsigned long lastMillis1;                         // Merker Zeit voriger Zyklus für Zeitscheibe
unsigned long DelayLed[AnzahlLedMax];              // Verzögerung in Anzahl Zyklen
uint8_t LedZaehler;                                // Abarbeitungs-Zaehler für Led
uint32_t ColorRoh[AnzahlLedMax];                   // Zwischenresultat Farbumrechnung
uint32_t ColorGamma[AnzahlLedMax];                 // Zwischenresultat Farbumrechnung
uint8_t Val[AnzahlLedMax];                         // Val
uint32_t Hue1[AnzahlLedMax];                       // Hue Wert1
uint8_t Sat1[AnzahlLedMax];                        // Sat Wert1
uint8_t Val1[AnzahlLedMax];                        // Val Wert1
uint32_t Hue2[AnzahlLedMax];                       // Hue Wert2
uint8_t Sat2[AnzahlLedMax];                        // Sat Wert2
uint8_t Val2[AnzahlLedMax];                        // Val Wert2
uint8_t AnzahlWS2812Benutzt;                       // Anzahl Benutzte WS2812
uint8_t AnzahlPL9823Benutzt;                       // Anzahl Benutzte PL9823
uint8_t AnzahlLedBenutzt;                          // Anzahl Benutzte LED

uint32_t HueTV[AnzahlTV];                          // Hue Wert TV
uint8_t SatTV[AnzahlTV];                           // Sat Wert TV
uint8_t ValTV[AnzahlTV];                           // Val Wert TV
uint32_t Hue1TV[AnzahlTV];                         // Hue Wert TV
uint8_t Sat1TV[AnzahlTV];                          // Sat Wert TV
uint8_t Val1TV[AnzahlTV];                          // Val Wert TV
uint32_t Hue2TV[AnzahlTV];                         // Hue Wert TV
uint8_t Sat2TV[AnzahlTV];                          // Sat Wert TV
uint8_t Val2TV[AnzahlTV];                          // Val Wert TV
uint8_t PhaseNrTV[AnzahlTV];                       // Val Wert TV
uint8_t TVNr;                                      // Zeiger TV Nr
uint8_t DelayTv[AnzahlTV];                         // Verzögerung in Anzahl Zyklen
uint8_t DelayTvSaved[AnzahlTV];                    // Verzögerung in Anzahl Altwert
uint8_t LedTestAktiv;                              // Merker für LED Test
uint8_t LedCopyState = 0;                          // Status für LED Kopieren (0=Aus, 1=Quelle gewählt, 2= Zielanfang gewählt)
uint8_t LedCopyZielAnfang;                         // Merker Zielanfang für LED kopieren
uint8_t LedCopyZielEnde;                           // Merker Zielende für LED kopieren
uint8_t LedCopyQuelle;                             // Merker Quelle für LED kopieren
uint8_t DeviceNr;                                  // Device Nummer für IP-Addresse und Namen
char DeviceNrText[2];                              // Devicenummer für IP-Addresse und Gerätenamen
uint8_t LedZeiger;                                 // Zeiger Led Nr
uint8_t Schritt[AnzahlLedMax];                     // Schritt Aktuell
uint8_t SchrittAlt[AnzahlLedMax];                  // Schritt Altwert für Flankenerkennung
boolean TvSchrittInit[AnzahlLedMax];               // TV Schritt initialisieren
boolean TvSchrittTeil2[AnzahlLedMax];              // TV Schritt Teil 2
unsigned long SchrittTimer[AnzahlLedMax];          // Zähler für Zeitsequenz der Schritte
unsigned long PhasenTimer[AnzahlLedMax];           // Zähler für Zeitsequenz der Phasen
unsigned long PhaseZeit[AnzahlLedMax];             // Phase Gesamtdauer
uint8_t PhasenAnzahl[AnzahlLedMax];                // Phase Gesamtanzahl
uint8_t Phase[AnzahlLedMax];                       // Phase Aktuell
uint8_t PhaseAlt[AnzahlLedMax];                    // Phase Altwert für Flankenerkennung
uint8_t LedInEditMode[AnzahlLedMax];               // Edit Mode
uint8_t LedInEditModeAlt[AnzahlLedMax];            // Edit Mode Altwert für Flankenerkennung
uint8_t LedInCopyMode[AnzahlLedMax];               // Copy Mode
uint8_t Farbe[AnzahlLedMax][AnzahlPhasenMax];      // Farbe
uint8_t Effekt[AnzahlLedMax][AnzahlPhasenMax];     // Effekt
uint8_t Helligkeit[AnzahlLedMax][AnzahlPhasenMax]; // Helligkeit
uint8_t Zeitwahl[AnzahlLedMax][AnzahlPhasenMax];   // Zeitauswahl
uint8_t FlackerZaehler[AnzahlLedMax];              // Flackerzähler für Neon
uint8_t FlackerZyklen[AnzahlLedMax];               // Flackerzyklen für Neon
bool LDRTrigger;                                    // Merker LDR Zustand
uint8_t LDRLevel;                                  // Automatisch Ein gemäss LDR
bool AusloeserTrigger;                             // Merker für Auslöser
uint8_t VersionGespeichert;                        // Version für Versionscheck
bool AutoEinWechsel;                               // Autoberieb gewechselt für LDR
bool SzenarioRestart;                              // Szenario neustarten
bool EffektAnwenden;                               // Effekt ist Anwendbar
File myFile;                                       // Datei-Objekt für DS Karte
uint8_t EinschaltIndex;                            // EinschaltIndex
uint8_t Gammaprofil;                               // Auswahl des Gammaprofiles
long EinschaltTimer;                               // EinschaltTimer
bool AnzahlPhasenWaehlen;                          // Merker ob Phase programmiert wird.
int PhaseAktuell;                                  // Aktuell gewählte Phase
//String htmlPage;                                   // String für Webseite

uint8_t i;    // Hilfswert Zähler
uint8_t n;    // Hilfswert Zähler
uint8_t k;    // Hilfswert Zähler
uint32_t rgb; // Hilfswert für Farbe
uint8_t r;    // Hilfswert rot
uint8_t g;    // Hilfswert grün
uint8_t b;    // Hilfswert blau

//■■  WEB Ausgabe-Texte ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
String EffektText;       // Ausgabetext Effekt
String ZeitText;         // Ausgabetext Zeeit
String HelligkeitsText;  // Ausgabetext Helligkeit
String GammaprofilText;  // Ausgabetext Gammaprofil
String AusloeserText;    // Ausgabetext Ausloeser
String LichtsensorText;  // Ausgabetext Lichtsensor

// Set the variable to the NUMBER of pixels
Adafruit_NeoPixel stripWS2812(AnzahlLedMax, dataPinWS2812, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel stripPL9823(AnzahlLedMax, dataPinPL9823, NEO_RGB + NEO_KHZ800);

/*
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
█        █████████  ████████        ███████████  ████████   ███████   █         █           █         █        ████████████████████████████████████████
█   ████   ██████  █  ██████   ████   ████████  █  ██████  █   ███    █   ███████████   █████   ███████   ████   ██████████████████████████████████████
█   ████   █████  ██   █████   ████   ███████  ██   █████   █   █ █   █   ███████████   █████   ███████   ████   ██████████████████████████████████████
█        ██████   ███   ████  █   ██████████   ███   ████   ██   ██   █       ███████   █████       ███  █   ██████████████████████████████████████████
█   ██████████       █   ███   ██   ███████       █   ███   ███  ██   █   ███████████   █████   ███████   ██   ████████████████████████████████████████
█   █████████   ███████   ██   ████   ████   ███████   ██   ███████   █   ███████████   █████   ███████   ████   ██████████████████████████████████████
█   ████████   █████████   █   ██████   █   █████████   █   ███████   █         █████   █████         █   ██████   ████████████████████████████████████
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void BuildParameterSite()
{
String htmlPage;
htmlPage = String("") +
"<!DOCTYPE HTML>" +
"<html>" +
"<head>" +  
  "<meta charset=""utf-8"">" +
  "<style>" +
    "html { font-family: Arial; margin: 0px auto;}" +
    "body {margin-top: 8px;}" +
    "table {width: 100%; background-color: #fef; border-collapse: collapse;}" +
    "td {width: 100%; font-family: Arial; font-size: 48px; padding: 5px; border: 8px solid red;}" +
    ".ButY {background-color:#fc0; border-radius:15px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".ButR {background-color:#f33; border-radius:10px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".ButB {background-color:#09f; border-radius:10px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".ButG {background-color:#bbb; border-radius:10px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".row {padding: 4px 0;}" +
  "</style>" +
"</head>" +
"<body>" +

  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value= &nbsp;&lt;&lt;&nbsp; onclick=location.href='/LedPrev5Prog'>" +
  "<input type=Button class=""ButY"" value=&lt;&nbsp;LED&nbsp; onclick=location.href='/LedPrevProg'>" +
  "<input type=Button class=""ButY"" value=&nbsp;LED&nbsp;&gt; onclick=location.href='/LedNextProg'>" +
  "<input type=Button class=""ButY"" value=&nbsp;&gt;&gt;&nbsp; onclick=location.href='/LedNext5Prog'>" +
  "<input type=Button class=""ButY"" value=Copy onclick=location.href='/Copy'>" +
  "<input type=Button class=""ButG"" value=&bigotimes;&nbsp; onclick=location.href='/ShowLED'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButG"" value=&nbsp;&#10132; onclick=location.href='/WaehlePhasenAnzahl'>" +
  "<input type=Button class=""ButY"" value=P1 onclick=location.href='/SetProg1'>" +
  "<input type=Button class=""ButY"" value=&nbsp;2&nbsp; onclick=location.href='/SetProg2'>" +
  "<input type=Button class=""ButY"" value=&nbsp;3&nbsp; onclick=location.href='/SetProg3'>" +
  "<input type=Button class=""ButY"" value=&nbsp;4&nbsp; onclick=location.href='/SetProg4'>" +
  "<input type=Button class=""ButY"" value=&nbsp;5&nbsp; onclick=location.href='/SetProg5'>" +
  "<input type=Button class=""ButY"" value=&nbsp;6&nbsp; onclick=location.href='/SetProg6'>" +
  "<input type=Button class=""ButY"" value=&nbsp;7&nbsp; onclick=location.href='/SetProg7'>" +
  "<input type=Button class=""ButY"" value=&nbsp;8&nbsp; onclick=location.href='/SetProg8'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=&nbsp;Ro&nbsp;&nbsp; onclick=location.href='/Farbe01'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Or&nbsp;&nbsp; onclick=location.href='/Farbe02'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Ge&nbsp;&nbsp; onclick=location.href='/Farbe03'>" +
  "<input type=Button class=""ButY"" value=Lim&nbsp; onclick=location.href='/Farbe04'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Gr&nbsp;&nbsp; onclick=location.href='/Farbe05'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Tü&nbsp;&nbsp; onclick=location.href='/Farbe06'>" +
  "</div>" +
  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=&nbsp;Cy&nbsp;&nbsp; onclick=location.href='/Farbe07'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Bl&nbsp;&nbsp; onclick=location.href='/Farbe08'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Lil&nbsp;&nbsp; onclick=location.href='/Farbe09'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Ma&nbsp;&nbsp; onclick=location.href='/Farbe10'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Pi&nbsp;&nbsp; onclick=location.href='/Farbe11'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Ki&nbsp;&nbsp; onclick=location.href='/Farbe12'>" +
  "</div>" +
  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=WaW onclick=location.href='/Farbe20'>" +
  "<input type=Button class=""ButY"" value=KaW onclick=location.href='/Farbe21'>" +
  "<input type=Button class=""ButY"" value=NeW onclick=location.href='/Farbe22'>&emsp;" +
  "<input type=Button class=""ButG"" value=TV1 onclick=location.href='/Farbe25'>" +
  "<input type=Button class=""ButG"" value=TV2 onclick=location.href='/Farbe26'>" +
  "<input type=Button class=""ButG"" value=TV3 onclick=location.href='/Farbe27'>" +
  "</div>" +
  "<div class=""row"">" +
  "<input type=Button class=""ButG"" value=&nbsp;Aus&nbsp; onclick=location.href='/Farbe00'>&emsp;" +
  "<input type=Button class=""ButG"" value=Wie-1 onclick=location.href='/Farbe15'>" +
  "<input type=Button class=""ButG"" value=-2 onclick=location.href='/Farbe16'>" +
  "<input type=Button class=""ButG"" value=-3 onclick=location.href='/Farbe17'>" +
  "<input type=Button class=""ButG"" value=-4 onclick=location.href='/Farbe18'>&emsp;" +
  "<input type=Button class=""ButR"" value=Alle&nbsp;Aus onclick=location.href='/AlleAus'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=&nbsp;Kon&nbsp; onclick=location.href='/Effekt00'>" +
  "<input type=Button class=""ButY"" value=&nbsp;LS1&nbsp; onclick=location.href='/Effekt01'>" +
  "<input type=Button class=""ButY"" value=&nbsp;LS2&nbsp; onclick=location.href='/Effekt02'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Feu1&nbsp; onclick=location.href='/Effekt03'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Feu2&nbsp; onclick=location.href='/Effekt04'>" +
  "</div>" +
  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=WK1 onclick=location.href='/Effekt05'>" +
  "<input type=Button class=""ButY"" value=WK2 onclick=location.href='/Effekt06'>" +
  "<input type=Button class=""ButY"" value=WK3 onclick=location.href='/Effekt07'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=0.1s onclick=location.href='/Time0k'>" +
  "<input type=Button class=""ButY"" value=0.2s onclick=location.href='/Time1k'>" +
  "<input type=Button class=""ButY"" value=0.5s onclick=location.href='/Time2k'>" +
  "<input type=Button class=""ButY"" value=&nbsp;1s&nbsp; onclick=location.href='/Time3k'>" +
  "<input type=Button class=""ButY"" value=2s&nbsp; onclick=location.href='/Time4k'>" +
  "<input type=Button class=""ButY"" value=3s&nbsp; onclick=location.href='/Time5k'>" +
  "<input type=Button class=""ButY"" value=5s&nbsp; onclick=location.href='/Time6k'>" +
  "</div>" +
  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=10s onclick=location.href='/Time7k'>" +
  "<input type=Button class=""ButY"" value=20s onclick=location.href='/Time8k'>" +
  "<input type=Button class=""ButY"" value=60s onclick=location.href='/Time9k'>&emsp;&emsp;" +
  "<input type=Button class=""ButY"" value=&asymp;1m&nbsp; onclick=location.href='/Time0z'>" +
  "<input type=Button class=""ButY"" value=&asymp;2m&nbsp; onclick=location.href='/Time1z'>" +
  "<input type=Button class=""ButY"" value=&asymp;3m&nbsp; onclick=location.href='/Time2z'>" +
  "</div>" +
  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=&asymp;5m&nbsp; onclick=location.href='/Time3z'>" +
  "<input type=Button class=""ButY"" value=&asymp;7m&nbsp; onclick=location.href='/Time4z'>" +
  "<input type=Button class=""ButY"" value=&asymp;10m onclick=location.href='/Time5z'>" +
  "<input type=Button class=""ButY"" value=&asymp;15m onclick=location.href='/Time6z'>" +
  "<input type=Button class=""ButY"" value=&asymp;20m onclick=location.href='/Time7z'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=Dunkel onclick=location.href='/Hell1'>" +
  "<input type=Button class=""ButY"" value=Mittel onclick=location.href='/Hell2'>" +
  "<input type=Button class=""ButY"" value=&nbsp;Hell&nbsp; onclick=location.href='/Hell3'>&emsp;" +
  "<input type=Button class=""ButB"" value=O1 onclick=location.href='/Settings1'>" +
  "<input type=Button class=""ButB"" value=O2 onclick=location.href='/Settings2'>" +
  "<input type=Button class=""ButB"" value=Leg onclick=location.href='/LegendeProg'>" +
  "</div>" +

  "<hr size=""10"" color=""blue"">" +
  "<table>" +
  "<tbody>" +
  "<tr><td>" + 
  "LED&nbsp;" + String(LedZeiger + 1) + "&emsp;(von&nbsp;" + String(AnzahlLedBenutzt) + ")&emsp;&emsp;&emsp;&emsp;Phase&nbsp;" + String(PhaseAktuell + 1) + "&nbsp;von&nbsp;" + String(PhasenAnzahl[LedZeiger] + 1) +
  "</td></tr>" +
  "<tr><td>" + 
  FarbTexte[Farbe[LedZeiger][PhaseAktuell]] + EffektText + ZeitText + HelligkeitsText + 
  "</td></tr>" +
  "</tbody>" +
  "</table>" +

"</body>" +
"</html>";
server.send(200, "text/html", htmlPage);
} // BuildParameterSite
/*
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
█████████████        █████████  ████████        █████████████████   ████████         ████     ██████████████████████████████████████████████
█████████████   ████   ██████  █  ██████   ████   ███████████████   ████████   ████████  ████   ████████████████████████████████████████████
█████████████   ████   █████  ██   █████   ████   ███████████████   ████████   ███████  ████████████████████████████████████████████████████
█████████████        ██████   ███   ████  █   ███████████████████   ████████       ███   ███████████████████████████████████████████████████
█████████████   ██████████       █   ███   ██   █████████████████   ████████   ███████   ███      ██████████████████████████████████████████
█████████████   █████████   ███████   ██   ████   ███████████████   ████████   ████████   ████  ████████████████████████████████████████████
█████████████   ████████   █████████   █   ██████   █████████████          █         ███      ██████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
char legendeprog[] PROGMEM = R"=====(
<!doctype html>

<html>
<head>  
  <meta charset="utf-8">
  <style>
    html {font-family: Arial; margin: 0px auto;}
    body {margin-top: 10px;} 
    h1 {color: #444444; margin: 10px auto 30px;} 
    .ButB {background-color:#09f; border-radius:10px; color:#000; font: bold 48px Arial; padding: 20px 25px;}
    .row {padding: 4px 0;}
    table.redTable {font-family: Arial, Helvetica, sans-serif; border: 4px solid #A40808; background-color: #EEE7DB; width: 100%; text-align: left; border-collapse: collapse;}
    table.redTable td, table.redTable th {border: 1px solid #000000; padding: 2px 8px; vertical-align:top; }
    table.redTable tbody td {font-size: 40px; color: #000000;}
    table.redTable tr:nth-child(even) {background: #F5C8BF;}
  </style>

</head>
<body>
  <div class="row">
  <input type=Button class="ButB" value=&emsp;Zurück&emsp; onclick=location.href='/Parameters'>
  </div>

<table class="redTable">
<tbody>
<tr><td>HINWEIS</td><td>Schalten Sie ggf. aktivierte Auslöser temporär aus während der Konfiguration. Sonst sehen Sie eventuell nicht, was Sie parametrieren.</td></tr>
<tr><td>&lt;&lt;</td><td>5 LEDs rückwärts springen</td></tr>
<tr><td>&lt; LED</td><td>1 LED rückwärts pringen</td></tr>
<tr><td>LED &gt;</td><td>1 LED vorwärts springen</td></tr>
<tr><td>&gt;&gt;</td><td>5 LEDs vorwärts springen</td></tr>
<tr><td>&bigotimes;</td><td>Lässt die aktuelle LED kuz aufblinken als Suchhilfe zum finden der LED.</td></tr>
<tr><td>Copy</td><td>Kopiert die Parameter von einer LED zu einer Gruppe von LEDs.<br>1. Die LED auswählen deren Parameter kopiert werden sollen.<br>2. Mit Copy merken.<br>3. Di erste LED des Zielbereichs anwählen und mit Copy merken.<br>4. Die etzte LED des Zielbereiches wählen und mit Copy den Kopiervorgang auslösen.<br>HINWEIS: Sollen die Parameter nur zu einer einzigen LED kopiert werden, dann Schritt 3 und 4 auf derselben LED ausführen.</td></tr>
<tr><td>&#10132;</td><td>Damit definieren Sie, wieviele Phasen Sie für die gewählte LED verwenden möchten.<br>1. Drücken Sie &#10132;.<br>2. Drücken sie eine Phasentaste um die gewünschte Anzahl Phasen zu definieren.<br>HINWEIS: Bei nur einer verwendeten Phase sind die Zeiten irrelevant, da keine Phasenwechsel geschehen.</td></tr>
<tr><td>P1<br>…<br>8</td><td>Phase 1 … 8.<br>Wählen Sie die zu parametrierende Phase.<br>HINWEIS: Durch vorgängige Bedienung von &#10132; definieren Sie die gewünschte Anzahl Phasen.</td></tr>
<tr><td>Ro<br>…<br>Ki</td><td>Farben: Rot / Orange / Gelb / Limette / Grün / Türkis / Cyan / Blau / Lila / Magenta / Rosa / Kirschrot</td></tr>
<tr><td>WaW</td><td>Warmweiss</td></tr>
<tr><td>KaW</td><td>Kaltweiss</td></tr>
<tr><td>NeW</td><td>Neutralweiss</td></tr>
<tr><td>TV1</td><td>Fernsehprogramm mit kleinen Farbsprüngen. Blasse Farben.<br>Z.B. Diskussionssendung.<br>Kein zusätzlicher Effekt anwendbar.</td></tr>
<tr><td>TV2</td><td>Fernsehprogramm mit mittleren Farbsprüngen. Mittelkräftige Farben.<br>Z.B. Spielfilm.<br>Kein zusätzlicher Effekt anwendbar.</td></tr>
<tr><td>TV3</td><td>Fernsehprogramm mit grossen Farbsprüngen. Kräfige Farben.<br>Kein zusätzlicher Effekt anwendbar.</td></tr>
<tr><td>Aus</td><td>Ausgeschaltet.<br>Kein zusätzlicher Effekt anwendbar.</td></tr>
<tr><td>Wie -1<br> - 2<br>- 3<br>- 4</td><td>LED verhält sich identisch zur LED vorher oder 2, 3, 4 LEDs vorher.<br>LED hat kein eigenes Verhalten.<br>Z.B. für identisches Verhalten einer Gruppe von LEDS oder für Lauflicht-Effekte.<br>Kein zusätzlicher Effekt anwendbar.</td></tr>
<tr><td>Alle<br>Aus</td><td>Alle LEDs ausschalten.<br>Z.B. um die Parametrierung einer neuen Szene zu beginnen.</td></tr>
<tr><td>Kon</td><td>Konstant ein (ohne Effekt).</td></tr>
<tr><td>LS1</td><td>Leuchstoffröhre mit Einschaltflackern (alter mechanischer Starter)</td></tr>
<tr><td>LS2</td><td>Leuchstoffröhre mit Dauerflackern (defekter mechanischer Starter)</td></tr>
<tr><td>Feu1</td><td>Feuer ruhig (z.B. Cheminé).</td></tr>
<tr><td>Feu2</td><td>Feuer lebhaft (z.B. Lagerfeuer).</td></tr>
<tr><td>WK1</td><td>Längerer Wackelkontakt alle 30...60 Sekunden</td></tr>
<tr><td>WK2</td><td>Mittlerer Wackelkontakt alle 8...15 Sekunden</td></tr>
<tr><td>WK3</td><td>Kurzer Wackelkontakt alle 1...6 Sekunden</td></tr>
<tr><td>0.1s<br>…<br>60s</td><td>Wartezeit mit exakter Dauer (z.B. auch für Blinktakte und Lauflichter über mehrere LEDs)<br>Wird für eine LED nur eine einzige Phase verwendet, so ist keine Zeit anwendbar, da keine Phasenwechsel geschehen.</td></tr>
<tr><td>≈1m<br>…<br>≈20m</td><td>Wartezeit ungenauer Dauer (zeitliche Streuung +-50%)<br>Wird für eine LED nur eine einzige Phase verwendet, so ist keine Zeit anwendbar.<br>D.h. die Auswahl einer Zeit ist in diesem Fall wirkungslos.</td></tr>
<tr><td>Dunkel<br>Mittel<br>Hell</td><td>Helligkeitsstufe</td></tr>
</tbody>
</table>

  <div class="row">
  <input type=Button class="ButB" value=&emsp;Zurück&emsp; onclick=location.href='/Parameters'>
  </div>
  </body>
</html>
)=====";
/*
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████     ██████        ███           ████████████████████████████████████████████████████████████████████████
█████████   ████   ███   ████   █████   ███████████   ██████████████████████████████████████████████████████████████
███████   ████████   █   ████   █████   ████████████   █████████████████████████████████████████████████████████████
███████   ████████   █        ███████   ████████████   █████████████████████████████████████████████████████████████
███████   ████████   █   ████████████   ████████████   █████████████████████████████████████████████████████████████
█████████   █████   ██   ████████████   ████████████   █████████████████████████████████████████████████████████████
███████████     ██████   ████████████   ███████████     ████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void BuildOptionen1Site()
{
String htmlPage;
htmlPage = String("") +
"<!DOCTYPE HTML>" +
"<html>" +
"<head>" +  
  "<meta charset=""utf-8"">" +
  "<style>" +
    "html { font-family: Arial; margin: 0px auto;}" +
    "body {margin-top: 10px;}" +
    "h1 {color: #000; margin: 0px auto 0px;}"
    "table {width: 100%; background-color: #fef; border-collapse: collapse;}" +
    "td {width: 100%; font-family: Arial; font-size: 48px; padding: 5px; border: 8px solid red;}" +
    ".ButY {background-color:#fc0; border-radius:15px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".ButR {background-color:#f33; border-radius:10px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".ButB {background-color:#09f; border-radius:10px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".ButG {background-color:#bbb; border-radius:10px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".ButGN {background-color:#5c1; border-radius:10px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".row {padding: 4px 0;}" +
  "</style>" +
"</head>" +
"<body>" +

  "<h1 style=""text-align: left;"">Controller-Nr:&nbsp;&nbsp;&nbsp;" +
  "<input type=Button class=""ButY"" value==&nbsp;1 onclick=location.href='/DevNrDefault'>" +
  "<input type=Button class=""ButY"" value=+&nbsp;10 onclick=location.href='/DevNrUp10'>" +
  "<input type=Button class=""ButY"" value=+&nbsp;1 onclick=location.href='/DevNrUp'>" +
  "<input type=Button class=""ButR"" value=Speichern onclick=location.href='/DevNrSet'>" +
  "</h1>" +

  "<hr size=""10"" color=""blue"">" +
  "<h1 style=""text-align: left;"">Anzahl Runde-LED PL9823:&nbsp;&nbsp;&nbsp;&nbsp;" +
  "<input type=Button class=""ButR"" value=&nbsp;&equals;&nbsp;0 onclick=location.href='/AnzPL9823Reset'>" +
  "<input type=Button class=""ButR"" value=&nbsp;&plus;&nbsp;1 onclick=location.href='/AnzPL9823Erhoehen'>" +
  "<input type=Button class=""ButR"" value=&nbsp;&plus;&nbsp;5 onclick=location.href='/AnzPL9823Erhoehen5'>" +
  "</h1>" +
  
  "<hr size=""10"" color=""blue"">" +
  "<h1 style=""text-align: left;"">Anzahl Streifen-LED WS2812:&nbsp;" +
  "<input type=Button class=""ButR"" value=&nbsp;&equals;&nbsp;0 onclick=location.href='/AnzWS2812Reset'>" +
  "<input type=Button class=""ButR"" value=&nbsp;&plus;&nbsp;1 onclick=location.href='/AnzWS2812Erhoehen'>" +
  "<input type=Button class=""ButR"" value=&nbsp;&plus;&nbsp;5 onclick=location.href='/AnzWS2812Erhoehen5'>" +
  "</h1>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=&nbsp;LED&nbsp;Test&nbsp;W&#10132;R&#10132;G&#10132;B&nbsp; onclick=location.href='/LedTestNext'>&emsp;" +
  "<input type=Button class=""ButY"" value=&nbsp;Beenden&nbsp; onclick=location.href='/LedTestAus'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButR"" value=S&nbsp;1 onclick=location.href='/Save1'>&emsp;&nbsp;" +
  "<input type=Button class=""ButR"" value=S&nbsp;2 onclick=location.href='/Save2'>&emsp;&nbsp;" +
  "<input type=Button class=""ButR"" value=S&nbsp;3 onclick=location.href='/Save3'>&emsp;&nbsp;" +
  "<input type=Button class=""ButR"" value=S&nbsp;4 onclick=location.href='/Save4'>&emsp;&nbsp;" +
  "<input type=Button class=""ButR"" value=S&nbsp;5 onclick=location.href='/Save5'>&emsp;&nbsp;" +
  "<input type=Button class=""ButR"" value=S&nbsp;6 onclick=location.href='/Save6'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButGN"" value=L&nbsp;1 onclick=location.href='/Load1'>&emsp;&nbsp;" +
  "<input type=Button class=""ButGN"" value=L&nbsp;2 onclick=location.href='/Load2'>&emsp;&nbsp;" +
  "<input type=Button class=""ButGN"" value=L&nbsp;3 onclick=location.href='/Load3'>&emsp;&nbsp;" +
  "<input type=Button class=""ButGN"" value=L&nbsp;4 onclick=location.href='/Load4'>&emsp;&nbsp;" +
  "<input type=Button class=""ButGN"" value=L&nbsp;5 onclick=location.href='/Load5'>&emsp;&nbsp;" +
  "<input type=Button class=""ButGN"" value=L&nbsp;6 onclick=location.href='/Load6'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButY"" value=Szenario&nbsp;Sync. onclick=location.href='/Synchronisation'>&emsp;" +
  "<input type=Button class=""ButGN"" value=&nbsp;Export&nbsp; onclick=location.href='/ExportSD'>&emsp;" +
  "<input type=Button class=""ButR"" value=&nbsp;Import&nbsp; onclick=location.href='/ImportSD'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<h1 style=""text-align: left;"">" +
  "<input type=Button class=""ButY"" value=Neustart onclick=location.href='/Neustart'>" +
  "&nbsp;Ev. erneutes Verbinden notwendig" +
  "</h1>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=Button class=""ButB"" value=Parameter onclick=location.href='/Parameters'>&emsp;" +
  "<input type=Button class=""ButB"" value=Optionen&nbsp;2 onclick=location.href='/Settings2'>&emsp;" +
  "<input type=Button class=""ButB"" value=&nbsp;Legende&nbsp; onclick=location.href='/LegendeSettings1'>" +
  "</div>" +

  "<hr size=""10"" color=""blue"">" +
  "<table>" +
  "<tbody>" +
  "<tr><td>" + 
  "Name: " + ssid + "&emsp;SW-Version:&nbsp;" + VersionAktuell +
  "<br>Controller-Nr. " + String(DeviceNr) + "&emsp;&emsp;&emsp;&emsp;IP: 192.168.1." + String(DeviceNr) + 
  "</td></tr>" +
  "<tr><td>" + 
  "&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Anzahl WS2812:&emsp;" + String(AnzahlWS2812Benutzt) + 
  "<br>&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&nbsp;Anzahl PL9823:&emsp;" + String(AnzahlPL9823Benutzt) +
  "<br>Anzahl LED gesamt (max 39):&emsp;" + String(AnzahlLedBenutzt) +
  "</td></tr>" +
  "</tbody>" +
  "</table>" +
  "</body>" +
"</html>";
server.send(200, "text/html", htmlPage);
} // BuildOptionen1Site
/*
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████     ██████        ███           ███████████████████   ████████         ████     ██████████████████████████████████████████████
█████████   ████   ███   ████   █████   ███████████   █████████   ████████   ████████  ████   ████████████████████████████████████████████
███████   ████████   █   ████   █████   ████████████   ████████   ████████   ███████  ████████████████████████████████████████████████████
███████   ████████   █        ███████   ████████████   ████████   ████████       ███   ███████████████████████████████████████████████████
███████   ████████   █   ████████████   ████████████   ████████   ████████   ███████   ███      ██████████████████████████████████████████
█████████   █████   ██   ████████████   ████████████   ████████   ████████   ████████   ████  ████████████████████████████████████████████
███████████     ██████   ████████████   ███████████     ███████          █         ███      ██████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
char legendeopt[] PROGMEM = R"=====(
<!doctype html>

<html>
<head>  
  <meta charset="utf-8">
  <style>
    html {font-family: Arial; margin: 0px auto;}
    body {margin-top: 10px;} 
    h1 {color: #444444; margin: 10px auto 30px;} 
    .ButB {background:linear-gradient(to bottom, #6be 5%, #48d 100%); border-radius:10px; color:#000; font: bold 48px Arial; padding: 18px 25px;}
    .row {padding: 4px 0;}
    table.redTable {font-family: Arial, Helvetica, sans-serif; border: 4px solid #A40808; background-color: #EEE7DB; width: 100%; text-align: left; border-collapse: collapse;}
    table.redTable td, table.redTable th {border: 1px solid #000000; padding: 2px 8px; vertical-align:top; }
    table.redTable tbody td {font-size: 40px; color: #000000;}
    table.redTable tr:nth-child(even) {background: #F5C8BF;}
  </style>
</head>
<body>

  <div class="row">
  <input type=Button class="ButB" value=&emsp;Zurück&emsp; onclick=location.href='/Settings1'>
  </div>

<table class="redTable">
<tbody>
<tr><td>= 1</td><td>Controller-Nr. = 01 <br>Name = LumiScene01<br>IP-Addresse = 192.168.1.1</td></tr>
<tr><td>+ 10</td><td>Controller-Nr. um 10 erhöhen<br>Name = LumiScene11 etc.<br>IP-Addresse = 192.168.1.11 etc.<br> Bis maximal 99.</td></tr>
<tr><td>+ 1</td><td>Controller-Nr. um 1 erhöhen<br>Name = LumiScene02 etc.<br>IP-Addresse = 192.168.1.2 etc.<br> Bis maximal 99.</td></tr>
<tr><td>Speichern</td><td>Controller-Nr. und IP-Addresse übernehmen und Controller neustarten.<br>Erneutes Verbinden notwendig.</td></tr>
<tr><td>HINWEIS</td><td>Passwort ist immer = 12345678</td></tr>
<tr><td>= 0</td><td>Anzahl verwendete LEDs = 0.<br>Wenn keine solchen LEDs verwendet werden oder als Start für die Einstellung der Anzahl verwendeten LEDs.</td></tr>
<tr><td>+ 1</td><td>Anzahl verwendete LEDs um 1 erhöhen.<br>Die letzte gewählte LED blinkt kurz.</td></tr>
<tr><td>+ 5</td><td>Anzahl verwendete LEDs um 5 erhöhen.<br>Die letzte gewählte LED blinkt kurz.</td></tr>
<tr><td>LED Test <br>WRGB</td><td>Alle LEDs testen mit Weiss, Rot, Grün, Blau.<br>Jede Bedienung wechselt zur nächsten Farbe.<br>Kann auch während dem Parametrieren der Anzahl LEDS verwendet werden.</td></tr>
<tr><td>Beenden</td><td>Stoppt den LED Test.<br>Kann auch während dem Parametrieren der Anzahl LEDS verwendet werden.</td></tr>
<tr><td>L 1<br>…<br>L 6</td><td>Komplettes Beleuchtungs-Szenario aus Speicherbank 1 … 6 laden.<br>HINWEIS: Nach dem Einschalten läuft immer das Szenario L1. (Autostart)</td></tr>
<tr><td>S 1<br>…<br>S 6</td><td>Komplettes Beleuchtungs-Szenario in Speicherbank 1 … 6 speichern.</td></tr>
<tr><td>Szenario Sync.</td><td>Synchronisiert den Start der Szenarien (wie nach dem Neustart oder dem Laden von Szenarien).<br>Wird nur benötigt um Blinktakte oder Lauflichter auf verschiedenen LEDs nach der Parametrierung auf Synchronizität zu prüfen ohne den Controller neuzustarten.</td></tr>
<tr><td>Export</td><td>Exportiert sämtliche Parametrierungen auf die SD Karte (falls SD Karte vorhanden).<br>Die SD-Karte muss FAT32 formatiert sein.<br>Die Namensgebung der Datei ist entsprechend dem Namen des Controllers.<br>Lumi01.csv für Lumiscene01,<br>Lumi02.csv für Lumiscene02 etc.<br>Eine vorhandene Datei wird überschrieben.</td></tr>
<tr><td>Import</td><td>Importiert sämtliche Parametrierungen von der SD Karte (falls SD Karte vorhanden und Datei vorhanden).</td></tr>
<tr><td>Neustart</td><td>Controller Neustart (Entspricht dem Drücken des Reset Buttons.<br>Wird normalerweise nicht benötigt.</td></tr>
</tbody>
</table>

  <div class="row">
  <input type=Button class="ButB" value=&emsp;Zurück&emsp; onclick=location.href='/Settings1'>
  </div>
<p>
</p>
</html>
)=====";
/*
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████     ██████        ███           ███████████████████████████████████████████████████████████████████████
█████████   ████   ███   ████   █████   ████████████   █  █████████████████████████████████████████████████████████
███████   ████████   █   ████   █████   ███████████  █████   ██████████████████████████████████████████████████████
███████   ████████   █        ███████   ████████████████   ████████████████████████████████████████████████████████
███████   ████████   █   ████████████   ██████████████   ██████████████████████████████████████████████████████████
█████████   █████   ██   ████████████   ████████████   ████████████████████████████████████████████████████████████
███████████     ██████   ████████████   ███████████         ███████████████████████████████████████████████████████
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void BuildOptionen2Site()
{
String htmlPage;
htmlPage = String("") +
"<!DOCTYPE HTML>" +
"<html>" +
"<head>" +  
  "<meta charset=""utf-8"">" +
  "<style>" +
    "html {font-family: Arial; margin: 0px auto;}" +
    "body {margin-top: 10px;}" +
    "table {width: 100%; background-color: #fef; border-collapse: collapse;}" +
    "td {width: 100%; font-family: Arial; font-size: 48px; padding: 5px; border: 8px solid red;}" +
    ".ButY {background-color:#fc0; border-radius:15px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".ButB {background-color:#09f; border-radius:10px; color:#000; font: bold 48px Arial; padding: 20px 25px;}" +
    ".row {padding: 4px 0;}" +
  "</style>" +
"</head>" +
"<body>" +
  "<div class=""row"">" +
  "<input type=button class=""ButY"" value=Auslöser&nbsp;Aus onclick=location.href='/TimeEin0'><br>" +
  "</div>" +
  "<div class=""row"">" +
  "<input type=button class=""ButY"" value=&nbsp;0s&nbsp;&nbsp; onclick=location.href='/TimeEin1'>&nbsp;" +
  "<input type=button class=""ButY"" value=15s&nbsp; onclick=location.href='/TimeEin2'>&nbsp;" +
  "<input type=button class=""ButY"" value=30s&nbsp; onclick=location.href='/TimeEin3'>&nbsp;" +
  "<input type=button class=""ButY"" value=1m&nbsp; onclick=location.href='/TimeEin4'>&nbsp;" +
  "<input type=button class=""ButY"" value=2m&nbsp; onclick=location.href='/TimeEin5'>&nbsp;" +
  "<input type=button class=""ButY"" value=5m&nbsp; onclick=location.href='/TimeEin6'>&nbsp;" +
  "</div>" +
  "<div class=""row"">" +
  "<input type=button class=""ButY"" value=10m onclick=location.href='/TimeEin7'>&nbsp;" +
  "<input type=button class=""ButY"" value=20m onclick=location.href='/TimeEin8'>&nbsp;" +
  "<input type=button class=""ButY"" value=30m onclick=location.href='/TimeEin9'>&nbsp;" +
  "<input type=button class=""ButY"" value=1h&nbsp;&nbsp; onclick=location.href='/TimeEin10'>&nbsp;" +
  "<input type=button class=""ButY"" value=2h&nbsp;&nbsp; onclick=location.href='/TimeEin11'>&nbsp;" +
  "<input type=button class=""ButY"" value=3h&nbsp;&nbsp; onclick=location.href='/TimeEin12'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<div class=""row"">" +
  "<input type=button class=""ButY"" value=&nbsp;Lichtsensor&nbsp;Aus&nbsp; onclick=location.href='/Eingeschaltet0'><br>" +
  "</div>" +
  "<div class=""row"">" +
  "<input type=button class=""ButY"" value=&nbsp;H6&nbsp; onclick=location.href='/Eingeschaltet6'>&nbsp;" +
  "<input type=button class=""ButY"" value=&nbsp;H5&nbsp; onclick=location.href='/Eingeschaltet5'>&nbsp;" +
  "<input type=button class=""ButY"" value=&nbsp;H4&nbsp; onclick=location.href='/Eingeschaltet4'>&nbsp;" +
  "<input type=button class=""ButY"" value=&nbsp;H3&nbsp; onclick=location.href='/Eingeschaltet3'>&nbsp;" +
  "<input type=button class=""ButY"" value=&nbsp;H2&nbsp; onclick=location.href='/Eingeschaltet2'>&nbsp;" +
  "<input type=button class=""ButY"" value=&nbsp;H1&nbsp; onclick=location.href='/Eingeschaltet1'>" +
  "</div>" +
  "<hr size=""10"" color=""blue"">" +

  "<h1 style=""text-align: left;"">Gamma-Profil:&emsp;" +
  "<input type=Button class=""ButY"" value=&emsp;Alt&emsp; onclick=location.href='/Gammaprofil1'>&emsp;" +
  "<input type=Button class=""ButY"" value=&emsp;Neu&emsp; onclick=location.href='/Gammaprofil2'>" +
  "</h1>" +
  "<hr size=""10"" color=""blue"">" +

 "<div class=""row"">" +
  "<input type=Button class=""ButB"" value=Parameter onclick=location.href='/Parameters'>&emsp;" +
  "<input type=Button class=""ButB"" value=Optionen&nbsp;1 onclick=location.href='/Settings1'>&emsp;" +
  "<input type=button class=""ButB"" value=Legende onclick=location.href='/LegendeSettings2'>" +
  "</div>" +

  "<hr size=""10"" color=""blue"">" +
  "<table>" +
  "<tbody>" +
  "<tr><td>" + 
  "Auslöser: " + AusloeserText + 
  "<br>Lichtsensor: " + LichtsensorText + 
  "</td></tr>""<tr><td>" + 
  "Gamma-Profil: " + GammaprofilText +
  "</td></tr>""<tr><td>" + 
  "Satus der Eingangssignale:" +
  "<br>&emsp;&emsp;&emsp;&emsp;&nbsp;&nbsp;Kontakt an D5:  " + !digitalRead(Kontakt) +
  "<br>Näherungssensor an D6:  " + digitalRead(PirSensor) +
  "<br>&emsp;&emsp;LDR-Eingang an A0:  " + analogRead(Photowiderstand) +
  "</td></tr>" +
  "</tbody>" +
  "</table>" +
  "</body>" +
"</html>";
server.send(200, "text/html", htmlPage);
} // BuildOptionen2Site
/*
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████     ██████        ███           ████████████████████████   ████████         ████     ██████████████████████████████████████████████
█████████   ████   ███   ████   █████   ████████████   █  ██████████   ████████   ████████  ████   ████████████████████████████████████████████
███████   ████████   █   ████   █████   ███████████  █████   ███████   ████████   ███████  ████████████████████████████████████████████████████
███████   ████████   █        ███████   ████████████████   █████████   ████████       ███   ███████████████████████████████████████████████████
███████   ████████   █   ████████████   ██████████████   ███████████   ████████   ███████   ███      ██████████████████████████████████████████
█████████   █████   ██   ████████████   ████████████   █████████████   ████████   ████████   ████  ████████████████████████████████████████████
███████████     ██████   ████████████   ███████████         ████████          █         ███      ██████████████████████████████████████████████
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
char legendeausloeser[] PROGMEM = R"=====(
<!doctype html>
<html>
<head>  
  <meta charset="utf-8">
  <style>
    html {font-family: Arial; margin: 0px auto;}
    body {margin-top: 10px;} 
    h1 {color: #444444; margin: 10px auto 30px;} 
    .ButB {background:linear-gradient(to bottom, #63b8ee 5%, #468ccf 100%); border-radius:10px; color:#000000; font: bold 48px Arial; padding: 18px 25px;}
    .row {padding: 4px 0;}
    table.redTable {font-family: Arial, Helvetica, sans-serif; border: 4px solid #A40808; background-color: #EEE7DB; width: 100%; text-align: left; border-collapse: collapse;}
    table.redTable td, table.redTable th {border: 1px solid #000000; padding: 2px 8px; vertical-align:top; }
    table.redTable tbody td {font-size: 40px; color: #000000;}
    table.redTable tr:nth-child(even) {background: #F5C8BF;}
</style>
</head>
<body>
  <div class="row">
  <input type=Button class="ButB" value=&emsp;Zurück&emsp; onclick=location.href='/Settings2'>
  </div>

<table class="redTable">
<tbody>
<tr><td>HINWEIS</td><td>Sind sowohl Auslöser aktiviert als auch Lichtsensor aktiviert in den Opionen, so müssen beide ansprechen, damit die Beleuchtung einschaltet.<br>Ausnahme: Das testen der LEDs ist jederzeit möglich.</td></tr>
<tr><td>Auslöser<br>Aus</td><td>Deaktiviert Auslöser wie PIR-Sensoren, Radar-Sensoren, Kontakt-Eingang, Tasten-Eingang. Die Auslöser haben keinen Einfluss auf die Beleuchtung.</td></tr>
<tr><td>0s<br>...<br>3h</td><td>Aktiviert Auslöser wie PIR-Sensoren, Radar-Sensoren und Kontakt-Eingang.<br>Ein Auslösen bewirkt das Einschalten der Beleuchtung für die gewählte EinschaltTimer.<br>Ein erneutes Auslösen während der Einschaltphase startet die Zeit neu, verlängert also die Einschaltphase.<br> Die Zeit 0s kann idealerweise verwendet werden, wenn die Zeit rein durch den Auslöser definiert sein soll.</td></tr>
<tr><td>Lichtsensor<br>Aus</td><td>Deaktiviert den Lichtsensor.<br>Der Lichtsensor hat keinen Einfluss auf die Beleuchtung.</td></tr>
<tr><td>H6<br>…<br>H1</td><td>Der Lichtsensor ist aktiviert.<br>Er schaltet die Beleuchtung ein bei entsprechender Verdunklung der Umgebung.<br>Der Einschalt-Punkt für die Beleuchtungen ist von relativ hell (H6) bis relativ dunkel (H1) wählbar.<br>Die Beleuchtung ist nur so lange aktiv wie die Umgebung ensprechend abgedunkelt ist.<br></td></tr>
<tr><td>Alt</td><td>Verwendung von Gammaprofil Alt (für ältere LED-Streifen-Bestellung in älteren Projekten)</td></tr>
<tr><td>Neu</td><td>Verwendung von Gammaprofil Neu (für neuere LED-Streifen-Bestellung in neueren Projekten)</td></tr>
<tr><td>Status</td><td>Zur Analyse von Hardware-Problemen.<br>Zeigt die Zustände an den Controller-Eingängen.<br>D5 & D6:<br>0 = nicht ausgelöst.<br>1 = ausgelöst.<br>A0 zeigt die Werte 0...1024. </td></tr>
</tbody>
</table>

  <div class="row">
  <input type=Button class="ButB" value=&emsp;Zurück&emsp; onclick=location.href='/Settings2'>
  </div>
</html>
)=====";
/*
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████        ███        █████████     ██████        █   █         █      █████   █████   █        ████████████████████████████
███████   ████   █   ████   █████   ████   ██████████   ███   ███████   ███   ██   █████   █   ████   ██████████████████████████
███████   ████   █   ████   ███   ████████   ███████   ████   ███████   ████   █   █████   █   ████   ██████████████████████████
███████        ███  █   ███████   ████████   █████   ██████       ███   ████   █   █████   █  █   ██████████████████████████████
███████   ████████   ██   █████   ████████   ████   ███████   ███████   ████   █   █████   █   ██   ████████████████████████████
███████   ████████   ████   █████   █████   ███   █████████   ███████   ███   ██   █████   █   ████   ██████████████████████████
███████   ████████   ██████   █████     ██████            █         █      ███████      ████   ██████   ████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void BeleuchtungAktiv(uint8_t Zustand)
{
  digitalWrite(BeleuchtungAktiv0, !Zustand);
  digitalWrite(BeleuchtungAktiv1, Zustand);
} //BeleuchtungAktiv
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
static uint8_t Kombiniere5BitUnd3BitWert(uint8_t FuenfBit, uint8_t DreiBit)
{ // Kombiniert 5 Bit und 3 Bit in einem Byte
  return (uint8_t)((FuenfBit << 3) | DreiBit);
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
static uint8_t Extrahiere5BitWert(uint8_t Wert)
{ // Ermittelt die linken 5 Bit aus einem Byte
  return (uint8_t)(Wert >> 3);
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
static uint8_t Extrahiere3BitWert(uint8_t Wert)
{ // Ermittelt  die rechten 3 Bit aus einem Byte.
  return (uint8_t)(Wert & 7);
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void ExportConfigToSd()
{
  unsigned int Addresse;
  uint8_t help;
  String Dateiname; // Hilfswert für Dateiname

  if (SD.begin(4)) //SD Karte vorhanden
  {
    EEPROM.get(EepromAddrDeviceNr, help); //Devicenummer von EEprom lesen
    Dateiname = "Lumi";
    if((int)help < 10) {Dateiname = Dateiname + "0";}
    Dateiname = Dateiname + (int)help;
    Dateiname = Dateiname + ".csv";

    SD.remove(Dateiname);                    //File löschen
    myFile = SD.open(Dateiname, FILE_WRITE); //File schreibend öffnen

    if (myFile) //File ist geöffnet
    {
      myFile.print(help); //Devicenummer
      myFile.print(Trennzeichen);
      EEPROM.get(EepromAddrAnzahlWS2812, help); //AnzahlWS2812 von EEprom lesen
      myFile.print(help);
      myFile.print(Trennzeichen);
      EEPROM.get(EepromAddrAnzahlPL9823, help); //AnzahlPL9823 von EEprom lesen
      myFile.print(help);
      myFile.print(Trennzeichen);
      EEPROM.get(EepromAddrAnzahlLED, help); //AnzahlLED, von EEprom lesen
      myFile.print(help);
      myFile.print(Trennzeichen);
      EEPROM.get(EepromAddrLDRLevel, help); //LDRLevel von EEprom lesen
      myFile.print(help);
      myFile.print(Trennzeichen);
      EEPROM.get(EepromAddrVersion, help); //Version von EEprom lesen
      myFile.print(help);
      myFile.print(Trennzeichen);
      EEPROM.get(EepromAddrReserve, help); //Reserve
      myFile.print(88); //Reservewert
      myFile.print(Trennzeichen);
      EEPROM.get(EepromAddrEinschaltIndex, help); //EinschaltIndex von EEprom lesen
      myFile.print(help);
      myFile.print(Trennzeichen);
      EEPROM.get(EepromAddrGammaprofil, help); //Gammaprofil von EEprom lesen
      myFile.print(help);
      myFile.print(Trennzeichen);
      // Ggf. weitere der 20 Einzelparameter hier einfügen.
      myFile.println();

      Addresse = EepromAnzahlEinzelwerte;

      for (k = 0; k < AnzahlSzenarios; k++)
      {
        myFile.print("SZENARIO");
        myFile.println();
        for (i = 0; i < AnzahlLedMax; i++)
        {
          EEPROM.get(Addresse, help); //Wert von EEprom lesen
          Addresse++;
          myFile.print(help);
          myFile.print(Trennzeichen);
          myFile.print("/");
          myFile.print(Trennzeichen);
          for (n = 0; n < AnzahlPhasenMax; n++)
          {
            EEPROM.get(Addresse, help);
            Addresse++;
            myFile.print(Extrahiere5BitWert(help)); //Farbe
            myFile.print(Trennzeichen);
            myFile.print(Extrahiere3BitWert(help)); //Effekt
            myFile.print(Trennzeichen);
            EEPROM.get(Addresse, help);
            Addresse++;
            myFile.print(Extrahiere5BitWert(help)); //Zeitwahl
            myFile.print(Trennzeichen);
            myFile.print(Extrahiere3BitWert(help)); //Helligkeit
            myFile.print(Trennzeichen);
            myFile.print("/");
            myFile.print(Trennzeichen);
          }
          myFile.println();
        }
      }
    }
    myFile.close(); //File schliessen
  }
} //ExportConfigToSd
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void ImportConfigFromSD()
{
  unsigned int Addresse;
  uint8_t help;
  String Dateiname; // Hilfswert für Dateiname
  String s; // Hilfswert für Strings
  String t; // Hilfswert für Strings

  if (SD.begin(4)) //SD Karte vorhanden
  {
    EEPROM.get(EepromAddrDeviceNr, help); //Devicenummer von EEprom lesen
    Dateiname = "Lumi";
    if((int)help < 10) {Dateiname = Dateiname + "0";}
    Dateiname = Dateiname + (int)help;
    Dateiname = Dateiname + ".csv";

    myFile = SD.open(Dateiname); //File lesend öffnen

    if (myFile) //File ist geöffnet
    {
      s = myFile.readStringUntil(Trennzeichen); //Devicenummer
      // EEPROM.put(EepromAddrDeviceNr, s.toInt());  Devicenummer nicht schreiben.
      s = myFile.readStringUntil(Trennzeichen); //Anzahl WS2812
      AnzahlPL9823Benutzt = s.toInt();
      EEPROM.put(EepromAddrAnzahlWS2812, AnzahlWS2812Benutzt);
      stripWS2812.updateLength(AnzahlWS2812Benutzt);
      s = myFile.readStringUntil(Trennzeichen);//Anzahl PL9823
      AnzahlPL9823Benutzt = s.toInt();
      EEPROM.put(EepromAddrAnzahlPL9823, AnzahlPL9823Benutzt);
      stripPL9823.updateLength(AnzahlPL9823Benutzt);
      s = myFile.readStringUntil(Trennzeichen); //Anzahl LED total
      EEPROM.put(EepromAddrAnzahlLED, s.toInt());
      s = myFile.readStringUntil(Trennzeichen); //LDRLevel
      EEPROM.put(EepromAddrLDRLevel, s.toInt());
      s = myFile.readStringUntil(Trennzeichen); //Version
      EEPROM.put(EepromAddrVersion, s.toInt());
      s = myFile.readStringUntil(Trennzeichen); //Reserve
      EEPROM.put(EepromAddrReserve, s.toInt());
      s = myFile.readStringUntil(Trennzeichen); //EinschaltIndex
      EEPROM.put(EepromAddrEinschaltIndex, s.toInt());
      s = myFile.readStringUntil(Trennzeichen); //Gammaprofil
      EEPROM.put(EepromAddrGammaprofil, s.toInt());
      // Ggf. weitere der 20 Einzelparameter hier einfügen.

      stripPL9823.updateLength(AnzahlPL9823Benutzt);
      
      Addresse = EepromAnzahlEinzelwerte;

      for (k = 0; k < AnzahlSzenarios; k++)
      {
        s = myFile.readStringUntil(Trennzeichen); //"SZENARIO"
        for (i = 0; i < AnzahlLedMax; i++)
        {
          s = myFile.readStringUntil(Trennzeichen); //Phasen
          EEPROM.put(Addresse, s.toInt());
          Addresse++;
          s = myFile.readStringUntil(Trennzeichen); //Bindestrich
          for (n = 0; n < AnzahlPhasenMax; n++)
          {
            s = myFile.readStringUntil(Trennzeichen); //Farbe
            t = myFile.readStringUntil(Trennzeichen); //Effekt
            help = Kombiniere5BitUnd3BitWert(s.toInt(), t.toInt());
            EEPROM.put(Addresse, help);
            Addresse++;
            s = myFile.readStringUntil(Trennzeichen); //Zeitwahl
            t = myFile.readStringUntil(Trennzeichen); //Helligkeit
            help = Kombiniere5BitUnd3BitWert(s.toInt(), t.toInt());
            EEPROM.put(Addresse, help);
            Addresse++;
            myFile.print("-");
            myFile.print(Trennzeichen);
            s = myFile.readStringUntil(Trennzeichen); //Bindestrich
          }
        }
      }
    }
    myFile.close(); //File schliessen
  }
} //ImportConfigFromSD
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void SzenarioInitTriggern()
{
  for (i = 0; i < AnzahlLedBenutzt; i++) // Für jede LED
  {
    PhaseAlt[i] = Starterkennung;
  }
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
static uint8_t Gamma(uint8_t Farbe, float gamma, uint8_t Max)
{
  return (int)(((float)Max * pow(Farbe / 255.0, 1.0 / gamma)) + 0.5);
} // Gamma
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
bool isPL9823(uint8_t Led)
{
  return (Led < AnzahlPL9823Benutzt);
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void LedMarkieren()
{
  digitalWrite(Buzzer, HIGH);
  delay(20);
  digitalWrite(Buzzer, LOW);
  if (isPL9823(LedZeiger) || (AnzahlLedBenutzt == 0)) // PL9823 angwählt oder leine LED aktiviert
  {
    stripPL9823.setPixelColor(LedZeiger, UintMax, UintMax, UintMax);
    stripPL9823.show();
    delay(30);
    stripPL9823.setPixelColor(LedZeiger, 0, 0, UintMax);
    stripPL9823.show();
    delay(30);
    stripPL9823.setPixelColor(LedZeiger, UintMax, 0, 0);
    stripPL9823.show();
    delay(30);
    stripPL9823.setPixelColor(LedZeiger, UintMax, UintMax, UintMax);
    stripPL9823.show();
    delay(30);
    stripPL9823.setPixelColor(LedZeiger, 0, 0, 0);
    stripPL9823.show();
    delay(30);
  }
  if (!isPL9823(LedZeiger) || (AnzahlLedBenutzt == 0)) // PL9823 angwählt oder leine LED aktiviert
  {
    stripWS2812.setPixelColor(LedZeiger - AnzahlPL9823Benutzt, UintMax, UintMax, UintMax);
    stripWS2812.show();
    delay(30);
    stripWS2812.setPixelColor(LedZeiger - AnzahlPL9823Benutzt, 0, 0, UintMax);
    stripWS2812.show();
    delay(30);
    stripWS2812.setPixelColor(LedZeiger - AnzahlPL9823Benutzt, UintMax, 0, 0);
    stripWS2812.show();
    delay(30);
    stripWS2812.setPixelColor(LedZeiger - AnzahlPL9823Benutzt, UintMax, UintMax, UintMax);
    stripWS2812.show();
    delay(30);
    stripWS2812.setPixelColor(LedZeiger - AnzahlPL9823Benutzt, 0, 0, 0);
    stripWS2812.show();
    delay(30);
  }
} // WS2812Markieren
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Settings1()
{
  LedMarkieren();
  BuildOptionen1Site();
} // handle_WS2812
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void ParameterWebTexteErmitteln()
{
  int farbe;
  farbe = Farbe[LedZeiger][PhaseAktuell];
  if ((farbe == 0) || (farbe == 15) || (farbe == 16) || (farbe == 17) || (farbe == 18) || (farbe == 25) || (farbe == 26) || (farbe == 27)) // Effekt irrelevant
  {
    EffektText = ""; // keine Angabe
  }
  else
  {
    EffektText = EffektTexte[Effekt[LedZeiger][PhaseAktuell]]; // Effekttext ermitteln
  }
  if (PhasenAnzahl[LedZeiger] > 0) //Wenn mehr als eine Phase verwendet wird
  {
    ZeitText = ZeitTexte[Zeitwahl[LedZeiger][PhaseAktuell]];  // Zeit anzeigen
  }
  else
  {
    ZeitText = ""; // Keine Zeit anzeigen
  }
  if ((farbe == 0)|| (farbe == 15) || (farbe == 16) || (farbe == 17) || (farbe == 18)) // Helligkeit irrelevant
  {
    HelligkeitsText = "";  //Keine Angabe
  }
  else
  {
    HelligkeitsText = HelligkeitTexte[Helligkeit[LedZeiger][PhaseAktuell]];  // Helligkeitstext ermitteln
  }
} // ParameterWebTexteErmitteln
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Parameters()
{
  LedMarkieren();
  ParameterWebTexteErmitteln();
  BuildParameterSite();
} // handle_Parameters
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void Settings2WebTexteErmitteln()
{
  AusloeserText = AusloeserTexte[EinschaltIndex];
  LichtsensorText = LichtsensorTexte[LDRLevel];
  GammaprofilText = GammaprofilTexte[Gammaprofil];
} // Settings2WebTexteErmitteln
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Settings2()
{
  Settings2WebTexteErmitteln();
  LedMarkieren();
  BuildOptionen2Site();
} // handle_Settings2
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_LegendeProg()
{
  LedMarkieren();
  server.send(200, "text/html", legendeprog);
} // handle_LegendeProg
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_LegendeSettings1()
{
  LedMarkieren();
  server.send(200, "text/html", legendeopt);
} // handle_LegendeSettings1
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_LegendeSettings2()
{
  LedMarkieren();
  server.send(200, "text/html", legendeausloeser);
} // handle_LegendeSettings2
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void LDRAuswerten()
{
  if (LDRLevel == 0) // LDR deaktiviert
  {
    LDRTrigger = true; // Beleuchtung immer an
  }
  else // LDR aktiviert
  {
    if (analogRead(Photowiderstand) < LDRGrenze[LDRLevel])
    {
      LDRTrigger = true;
    }
    if (analogRead(Photowiderstand) > (LDRGrenze[LDRLevel] + LDRHysterese[LDRLevel]))
    {
      LDRTrigger = false;
    } 
  }
} //void LDRAuswerten()

//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void AusloeserAuswerten()
{
  if (EinschaltIndex == 0) // Auslöser deaktiviert
  {
    EinschaltTimer = 0; // Zeit Zurücksetzen.
    AusloeserTrigger = true;  // Beleuchtung immer ein
  }
  else // Auslöser aktiviert
  {
    if (digitalRead(PirSensor) || !digitalRead(Kontakt)) // Wenn einer der Auslöser anspricht
    {
      EinschaltTimer = EinschaltZeit[EinschaltIndex]; // Timer "aufziehen"
    }
    if (EinschaltTimer > 0) //Wenn die Zeit noch läuft
    {
      EinschaltTimer--; //Einschaltzeit runterzählen
      AusloeserTrigger = true;  // Beleuchtung ein
    }
    else
    {
      AusloeserTrigger = false; // Beleuchtung aus
    }
  }
} //AusloeserAuswerten
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void AlleEditModeVerlassen()
{
  uint8_t Led;
  for (Led = 0; Led < AnzahlLedMax; Led++)
  {
    LedInEditMode[Led] = 0;
  }
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void LedsAusschalten()
{
stripWS2812.clear(); //Alle LEDs aus
stripPL9823.clear(); //Alle LEDs aus
stripWS2812.show();  //LEDS zeigen
stripPL9823.show();  //LEDs zeigen
} //LedsAusschalten
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void AllePhasenResetten()
{
  for (i = 0; i < AnzahlLedMax; i++)
  {
    PhasenAnzahl[i] = 0; // Alle Phasen Anzahlen zurücksetzen
    for (n = 0; n < AnzahlPhasenMax; n++)
    {
      Farbe[i][n] = 0;    // (Aus)
      Zeitwahl[i][n] = 5; // Fünfte Zeitwahl vorbesetzen
      Helligkeit[i][n] = HelligkeitMax;
    }
    LedZeiger = 0;
  }
} // AllePhasenResetten
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void Save(int8_t SetNr)
{
  unsigned int Addresse;
  uint8_t help;

  Addresse = (SetNr * AnzahlLedMax * (AnzahlByteProSzene + (AnzahlByteProPhase * AnzahlPhasenMax))) + EepromAnzahlEinzelwerte;

  for (i = 0; i < AnzahlLedMax; i++)
  {
    EEPROM.put(Addresse, PhasenAnzahl[i]);
    Addresse++;
    for (n = 0; n < AnzahlPhasenMax; n++)
    {
      help = Kombiniere5BitUnd3BitWert(Farbe[i][n], Effekt[i][n]);
      EEPROM.put(Addresse, help);
      Addresse++;
      help = Kombiniere5BitUnd3BitWert(Zeitwahl[i][n], Helligkeit[i][n]);
      EEPROM.put(Addresse, help);
      Addresse++;
    }
  }
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  handle_Settings1();
} // Save
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void Load(uint8_t SetNr)
{
  unsigned int Addresse;
  uint8_t help;

  AllePhasenResetten();
  Addresse = (SetNr * AnzahlLedMax * (AnzahlByteProSzene + (AnzahlByteProPhase * AnzahlPhasenMax))) + EepromAnzahlEinzelwerte;

  for (i = 0; i < AnzahlLedMax; i++)
  {
    EEPROM.get(Addresse, PhasenAnzahl[i]); //Wert von EEprom lesen
    Addresse++;
    for (n = 0; n < AnzahlPhasenMax; n++)
    {
      EEPROM.get(Addresse, help);
      Addresse++;
      Farbe[i][n] = Extrahiere5BitWert(help);
      Effekt[i][n] = Extrahiere3BitWert(help);
      EEPROM.get(Addresse, help);
      Addresse++;
      Zeitwahl[i][n] = Extrahiere5BitWert(help);
      Helligkeit[i][n] = Extrahiere3BitWert(help);
    }
    LedInEditMode[i] = 0;
  }
  SzenarioRestart = true;
  AlleEditModeVerlassen();
  SzenarioInitTriggern();
} // Load
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
int map4(int in, int x_1, int x_2, int x_3, int x_4, int y_1, int y_2, int y_3, int y_4)
{ //Interpolation auf einem Polygonzug mit vier Stützpunkten

  if (in < x_2)
  {
    return map(in, x_1, x_2, y_1, y_2);
  }
  else if (in < x_3)
  {
    return map(in, x_2, x_3, y_2, y_3);
  }
  else
  {
    return map(in, x_3, x_4, y_3, y_4);
  }
} // map4
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void HSV2ToHSV1(uint8_t Led)
{
  Hue1[Led] = Hue2[Led];
  Sat1[Led] = Sat2[Led];
  Val1[Led] = Val2[Led];
} // HSV2ToHSV1
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void HSV2ToHSV1TV(uint8_t Led)
{
  Hue1TV[Led] = Hue2TV[Led];
  Sat1TV[Led] = Sat2TV[Led];
  Val1TV[Led] = Val2TV[Led];
} // HSV2ToHSV1TV
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
unsigned long Zeit(uint8_t Zeitcode) // Zeiten für einzelne LEDs
{
  switch (Zeitcode)
  {
  case 0:
    return Faktor * 0.1; // 0.1s
    break;
  case 1:
    return Faktor * 0.2; // 0.2s
    break;
  case 2:
    return Faktor * 0.5; // 0.5s
    break;
  case 3:
    return Faktor * 1; // 1s
    break;
  case 4:
    return Faktor * 2; // 2s
    break;
  case 5:
    return Faktor * 3; // 3s
    break;
  case 6:
    return Faktor * 5; // 5s
    break;
  case 7:
    return Faktor * 10; // 10s
    break;
  case 8:
    return Faktor * 20; // 20s
    break;
  case 9:
    return Faktor * 60; // 60s
    break;

  case 10:
    return random(Faktor * 30, Faktor * 90); // ca1m:  0.5m...1.5m
    break;
  case 11:
    return random(Faktor * 60, Faktor * 180); // ca2m:  1m...3m
    break;
  case 12:
    return random(Faktor * 120, Faktor * 240); // ca3m:  2m...4m
    break;
  case 13:
    return random(Faktor * 150, Faktor * 450); // ca5m:  2.5m...7.5m
    break;
  case 14:
    return random(Faktor * 210, Faktor * 630); // ca7m:  3.5m...10.5m
    break;
  case 15:
    return random(Faktor * 300, Faktor * 900); // ca10m:  5m..15m
    break;
  case 16:
    return random(Faktor * 450, Faktor * 1350); // ca15m:  7.5m...22.5m
    break;
  case 17:
    return random(Faktor * 600, Faktor * 1800); // ca20m:  10m..30m
    break;
  default:
    return random(Faktor * 60, Faktor * 180); // ca2m:  1m...3m
    break;
  }
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void PhasenAnzahlWaehlen()
{
  AnzahlPhasenWaehlen = true;
  handle_Parameters();
} // PhasenAnzahlWaehlen
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void PhaseWaehlen(uint8_t Nummer)
{
  if (AnzahlPhasenWaehlen == true)  // Anzahl Phasen wählen
  {
  LedInEditMode[LedZeiger] = 1;
  PhasenAnzahl[LedZeiger] = Nummer;
  PhaseAktuell = 0;
  }
  else  // Phase auswählen
  {
    PhaseAktuell = min(Nummer, PhasenAnzahl[LedZeiger]);
  }
  PhaseAlt[LedZeiger] = Starterkennung;
  AnzahlPhasenWaehlen = false;
  handle_Parameters();
} // SzeneParametrieren
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void FarbeParametrieren(uint8_t Nummer)
{
  LedInEditMode[LedZeiger] = 1;
  Farbe[LedZeiger][PhaseAktuell] = Nummer;
  PhaseAlt[LedZeiger] = Starterkennung;
  handle_Parameters();
} // ProgParametrieren
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void EffektParametrieren(uint8_t Nummer)
{
  LedInEditMode[LedZeiger] = 1;
  Effekt[LedZeiger][PhaseAktuell] = Nummer;
  PhaseAlt[LedZeiger] = Starterkennung;
  handle_Parameters();
} // ProgParametrieren
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void ZeitParametrieren(uint8_t Nummer)
{
  Zeitwahl[LedZeiger][PhaseAktuell] = Nummer;
  LedInEditMode[LedZeiger] = 1;
  PhaseAlt[LedZeiger] = Starterkennung;
  handle_Parameters();
} // ZeitParametrieren
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void HellParametrieren(uint8_t Nummer)
{
  Helligkeit[LedZeiger][PhaseAktuell] = Nummer;
  LedInEditMode[LedZeiger] = 1;
  PhaseAlt[LedZeiger] = Starterkennung;
  handle_Parameters();
} // HellParametrieren
/*
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████     █████   █████   █           █████     ██████    █████   ███████        █████████  ████████        ██████████████████████
███████  ██   ███   █████   █████   ███████   ████   ███  █   ███   ███████   ████   ██████  █  ██████   ████   ████████████████████
███████  ███   ██   █████   █████   █████   ████████   █   █   ██   ███████   ████   █████  ██   █████   ████   ████████████████████
███████      ████   █████   █████   █████   ████████   █   ██   █   ███████        ██████   ███   ████  █   ████████████████████████
███████  ████   █   █████   █████   █████   ████████   █   ███  █   ███████   ██████████       █   ███   ██   ██████████████████████
███████  █████  █   █████   █████   ███████   █████   ██   ████  █  ███████   █████████   ███████   ██   ████   ████████████████████
███████    █   ████      ████████   █████████     ██████   ██████   ███████   ████████   █████████   █   ██████   ██████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void LedZeigerWechseln()
{
  AlleEditModeVerlassen();
  handle_Parameters();
} // LedNrAktualisierenProg
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Waehe5LedMinus()
{
  PhaseAlt[LedZeiger] = Starterkennung;
  PhaseAktuell = 0;
  if (LedZeiger > 4)
  {
    LedZeiger = LedZeiger - 5;
  }
  else
  {
    LedZeiger = 0;
  }
  LedZeigerWechseln();
} // handle_Waehe5LedMinus
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Waehe1LedMinus()
{
  PhaseAlt[LedZeiger] = Starterkennung;
  PhaseAktuell = 0;
  if (LedZeiger > 0)
  {
    --LedZeiger;
  }
  LedZeigerWechseln();
} // handle_Waehe1LedMinus
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Waehe1LedPlus()
{
  PhaseAlt[LedZeiger] = Starterkennung;
  PhaseAktuell = 0;
  if (LedZeiger < (AnzahlLedBenutzt - 1))
  {
    ++LedZeiger;
  }
  LedZeigerWechseln();
} // handle_Waehe1LedPlus
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Waehe5LedPlus()
{
  PhaseAlt[LedZeiger] = Starterkennung;
  PhaseAktuell = 0;
  if (LedZeiger < (AnzahlLedBenutzt - 6))
  {
    LedZeiger = LedZeiger + 5;
  }
  else
  {
    LedZeiger = AnzahlLedBenutzt - 1;
  }
  LedZeigerWechseln();
} // handle_Waehe5LedPlus
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Copy()
{
  switch (LedCopyState)
  {
  case 0: // Initialisieren: Led Quelle merken
    LedCopyQuelle = LedZeiger;
    LedInCopyMode[LedZeiger] = 1;
    LedCopyState = 1;
    break;
  case 1: // LED Zielanfang merken
    LedCopyZielAnfang = LedZeiger;
    LedInCopyMode[LedZeiger] = 1;
    LedCopyState = 2;
    break;
  case 2: // LED Parameter durchkopieren
    if (LedZeiger >= LedCopyZielAnfang)
    {                              // Ziel LED > als Quelle
      LedCopyZielEnde = LedZeiger; // Grössere Zahl ans Ende kopieren
    }
    else
    {
      LedCopyZielEnde = LedCopyZielAnfang; // Grössere Zahl ans Ende kopieren
      LedCopyZielAnfang = LedZeiger;       // Kleinere Zahl an den Anfang kopieren
    }
    LedInCopyMode[LedCopyQuelle] = 0;
    for (i = LedCopyZielAnfang; i <= LedCopyZielEnde; i++)
    {
      PhasenAnzahl[i] = PhasenAnzahl[LedCopyQuelle];
      LedInEditModeAlt[i] = 1; // Szenen Neustart provozieren
      for (n = 0; n < AnzahlPhasenMax; n++)
      {
        Farbe[i][n] = Farbe[LedCopyQuelle][n];
        Effekt[i][n] = Effekt[LedCopyQuelle][n];
        Helligkeit[i][n] = Helligkeit[LedCopyQuelle][n];
        Zeitwahl[i][n] = Zeitwahl[LedCopyQuelle][n];
      }
      LedInCopyMode[i] = 0;
      LedZeiger = LedCopyZielEnde;
      LedCopyState = 0;
    }
    break;
  default:
    break;
  }
  handle_Parameters();
} // handle_Copy
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_ShowLED()
{
  handle_Parameters();
} // handle_ShowLED
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_AlleLedAus()
{
  AllePhasenResetten();
  SzenarioInitTriggern();
  LedZeiger = 0;
  handle_Parameters();
} // handle_AlleSzenenResetten
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_WaehlePhasenAnzahl() { PhasenAnzahlWaehlen(); }
void handle_WaehlePhase1() { PhaseWaehlen(0); }
void handle_WaehlePhase2() { PhaseWaehlen(1); }
void handle_WaehlePhase3() { PhaseWaehlen(2); }
void handle_WaehlePhase4() { PhaseWaehlen(3); }
void handle_WaehlePhase5() { PhaseWaehlen(4); }
void handle_WaehlePhase6() { PhaseWaehlen(5); }
void handle_WaehlePhase7() { PhaseWaehlen(6); }
void handle_WaehlePhase8() { PhaseWaehlen(7); }
//▀▄��▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Farbe00() { FarbeParametrieren(0); }
void handle_Farbe01() { FarbeParametrieren(1); }
void handle_Farbe02() { FarbeParametrieren(2); }
void handle_Farbe03() { FarbeParametrieren(3); }
void handle_Farbe04() { FarbeParametrieren(4); }
void handle_Farbe05() { FarbeParametrieren(5); }
void handle_Farbe06() { FarbeParametrieren(6); }
void handle_Farbe07() { FarbeParametrieren(7); }
void handle_Farbe08() { FarbeParametrieren(8); }
void handle_Farbe09() { FarbeParametrieren(9); }
void handle_Farbe10() { FarbeParametrieren(10); }
void handle_Farbe11() { FarbeParametrieren(11); }
void handle_Farbe12() { FarbeParametrieren(12); }
void handle_Farbe15() { FarbeParametrieren(15); }
void handle_Farbe16() { FarbeParametrieren(16); }
void handle_Farbe17() { FarbeParametrieren(17); }
void handle_Farbe18() { FarbeParametrieren(18); }
void handle_Farbe20() { FarbeParametrieren(20); }
void handle_Farbe21() { FarbeParametrieren(21); }
void handle_Farbe22() { FarbeParametrieren(22); }
void handle_Farbe25() { FarbeParametrieren(25); }
void handle_Farbe26() { FarbeParametrieren(26); }
void handle_Farbe27() { FarbeParametrieren(27); }
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Effekt00() { EffektParametrieren(0); }
void handle_Effekt01() { EffektParametrieren(1); }
void handle_Effekt02() { EffektParametrieren(2); }
void handle_Effekt03() { EffektParametrieren(3); }
void handle_Effekt04() { EffektParametrieren(4); }
void handle_Effekt05() { EffektParametrieren(5); }
void handle_Effekt06() { EffektParametrieren(6); }
void handle_Effekt07() { EffektParametrieren(7); }
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Hell1() { HellParametrieren(0); }
void handle_Hell2() { HellParametrieren(1); }
void handle_Hell3() { HellParametrieren(2); }
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Time0k() { ZeitParametrieren(0); }
void handle_Time1k() { ZeitParametrieren(1); }
void handle_Time2k() { ZeitParametrieren(2); }
void handle_Time3k() { ZeitParametrieren(3); }
void handle_Time4k() { ZeitParametrieren(4); }
void handle_Time5k() { ZeitParametrieren(5); }
void handle_Time6k() { ZeitParametrieren(6); }
void handle_Time7k() { ZeitParametrieren(7); }
void handle_Time8k() { ZeitParametrieren(8); }
void handle_Time9k() { ZeitParametrieren(9); }
void handle_Time0z() { ZeitParametrieren(10); }
void handle_Time1z() { ZeitParametrieren(11); }
void handle_Time2z() { ZeitParametrieren(12); }
void handle_Time3z() { ZeitParametrieren(13); }
void handle_Time4z() { ZeitParametrieren(14); }
void handle_Time5z() { ZeitParametrieren(15); }
void handle_Time6z() { ZeitParametrieren(16); }
void handle_Time7z() { ZeitParametrieren(17); }
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄���▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Load0()
{
  Load(0);
  handle_Settings1();
} // handle_Load0
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Load1()
{
  Load(1);
  handle_Settings1();
} // handle_Load1
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Load2()
{
  Load(2);
  handle_Settings1();
} // handle_Load2
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Load3()
{
  Load(3);
  handle_Settings1();
} // handle_Load3
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Load4()
{
  Load(4);
  handle_Settings1();
} // handle_Load4
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Load5()
{
  Load(5);
  handle_Settings1();
} // handle_Load5
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Save0() { Save(0); } // handle_Save0
void handle_Save1() { Save(1); } // handle_Save1
void handle_Save2() { Save(2); } // handle_Save2
void handle_Save3() { Save(3); } // handle_Save3
void handle_Save4() { Save(4); } // handle_Save4
void handle_Save5() { Save(5); } // handle_Save5
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void ZeitEin(uint8_t Wert)
{
  EinschaltIndex = Wert;
  EEPROM.put(EepromAddrEinschaltIndex, EinschaltIndex);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  handle_Settings2();
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_TimeEin0() { ZeitEin(0); }
void handle_TimeEin1() { ZeitEin(1); }
void handle_TimeEin2() { ZeitEin(2); }
void handle_TimeEin3() { ZeitEin(3); }
void handle_TimeEin4() { ZeitEin(4); }
void handle_TimeEin5() { ZeitEin(5); }
void handle_TimeEin6() { ZeitEin(6); }
void handle_TimeEin7() { ZeitEin(7); }
void handle_TimeEin8() { ZeitEin(8); }
void handle_TimeEin9() { ZeitEin(9); }
void handle_TimeEin10() { ZeitEin(10); }
void handle_TimeEin11() { ZeitEin(11); }
void handle_TimeEin12() { ZeitEin(12); }
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void Einschalten(uint8_t WertNr)
{
  LDRLevel = WertNr;
  EEPROM.put(EepromAddrLDRLevel, LDRLevel);
  handle_Settings2();
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Eingeschaltet0() { Einschalten(0); } // handle_Eingeschaltet0
void handle_Eingeschaltet1() { Einschalten(1); } // handle_Eingeschaltet1
void handle_Eingeschaltet2() { Einschalten(2); } // handle_Eingeschaltet2
void handle_Eingeschaltet3() { Einschalten(3); } // handle_Eingeschaltet3
void handle_Eingeschaltet4() { Einschalten(4); } // handle_Eingeschaltet4
void handle_Eingeschaltet5() { Einschalten(5); } // handle_Eingeschaltet4
void handle_Eingeschaltet6() { Einschalten(6); } // handle_Eingeschaltet4
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_DeviceNrDefault()
{
  DeviceNr = 1;
  BuildOptionen1Site();
} // handle_DeviceNrDefault
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_DeviceNrAddrUp()
{
  DeviceNr++;
  DeviceNr = min(DeviceNr, DeviceNrMax);
  BuildOptionen1Site();
} // handle_DeviceNrAddrUp
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_DeviceNrAddrUp10()
{
  DeviceNr = DeviceNr + 10;
  DeviceNr = min(DeviceNr, DeviceNrMax);
  BuildOptionen1Site();
} // handle_DeviceNrAddrUp10
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_DeviceNrAktivieren()
{
  EEPROM.put(EepromAddrDeviceNr, DeviceNr);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  handle_AlleLedAus();
  ESP.restart();
} // handle_DeviceNrAktivieren
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Synchronisation()
{
  SzenarioRestart = true;
  handle_Settings1();
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_ExportSD()
{
  ExportConfigToSd();
  handle_Settings1();
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_ImportSD()
{
  ImportConfigFromSD();
  Load(0);
  handle_Settings1();
  // ESP.restart();
}
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Neustart()
{
  handle_Settings1();
  ESP.restart();
} // handle_Neustart
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void SetAnzahlLED()
{
  AnzahlLedBenutzt = AnzahlWS2812Benutzt + AnzahlPL9823Benutzt;
  EEPROM.put(EepromAddrAnzahlLED, AnzahlLedBenutzt);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
} // SetAnzahlLED
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_AnzahlPL9823Reset()
{
  AnzahlPL9823Benutzt = 0;
  LedZeiger = 0;
  stripPL9823.updateLength(AnzahlLedMax);
  EEPROM.put(EepromAddrAnzahlPL9823, AnzahlPL9823Benutzt);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  SetAnzahlLED();
  handle_Settings1();
} // handle_AnzahlPL9823Reset
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_AnzahlPL9823Erhoehen()
{
  AnzahlPL9823Benutzt++;
  if (AnzahlPL9823Benutzt > (AnzahlLedMax - AnzahlWS2812Benutzt))
  {
    AnzahlPL9823Benutzt = AnzahlLedMax;
  }
  LedZeiger = AnzahlPL9823Benutzt - 1;
  stripPL9823.updateLength(AnzahlPL9823Benutzt);
  EEPROM.put(EepromAddrAnzahlPL9823, AnzahlPL9823Benutzt);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  SetAnzahlLED();
  handle_Settings1();
} // handle_AnzahlPL9823Erhoehen
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_AnzahlPL9823Erhoehen5()
{
  AnzahlPL9823Benutzt = AnzahlPL9823Benutzt + 5;
  if (AnzahlPL9823Benutzt > (AnzahlLedMax - AnzahlWS2812Benutzt))
  {
    AnzahlPL9823Benutzt = AnzahlLedMax;
  }
  LedZeiger = AnzahlPL9823Benutzt - 1;
  stripPL9823.updateLength(AnzahlPL9823Benutzt);
  EEPROM.put(EepromAddrAnzahlPL9823, AnzahlPL9823Benutzt);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  SetAnzahlLED();
  handle_Settings1();
} // handle_AnzahlPL9823Erhoehen5
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_AnzahlWS2812Reset()
{
  AnzahlWS2812Benutzt = 0;
  LedZeiger = AnzahlPL9823Benutzt;
  stripWS2812.updateLength(AnzahlLedMax);
  EEPROM.put(EepromAddrAnzahlWS2812, AnzahlWS2812Benutzt);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  SetAnzahlLED();
  handle_Settings1();
} // handle_AnzahlWS2812Reset
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_AnzahlWS2812Erhoehen()
{
  AnzahlWS2812Benutzt++;
  if (AnzahlWS2812Benutzt > (AnzahlLedMax - AnzahlPL9823Benutzt))
  {
    AnzahlWS2812Benutzt = AnzahlLedMax;
  }
  else
  {
    LedZeiger = AnzahlWS2812Benutzt + AnzahlPL9823Benutzt - 1;
  }
  stripWS2812.updateLength(AnzahlWS2812Benutzt);
  EEPROM.put(EepromAddrAnzahlWS2812, AnzahlWS2812Benutzt);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  SetAnzahlLED();
  handle_Settings1();
} // handle_AnzahlWS2812Speichern
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_AnzahlWS2812Erhoehen5()
{
  AnzahlWS2812Benutzt = AnzahlWS2812Benutzt + 5;
  if (AnzahlWS2812Benutzt > (AnzahlLedMax - AnzahlPL9823Benutzt))
  {
    AnzahlWS2812Benutzt = AnzahlLedMax;
  }
  else
  {
    LedZeiger = AnzahlWS2812Benutzt + AnzahlPL9823Benutzt - 1;
  }
  stripWS2812.updateLength(AnzahlWS2812Benutzt);
  EEPROM.put(EepromAddrAnzahlWS2812, AnzahlWS2812Benutzt);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  SetAnzahlLED();
  handle_Settings1();
} // handle_AnzahlWS2812Erhoehen5
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Gammaprofil1()
{
  Gammaprofil = 0;
  EEPROM.put(EepromAddrGammaprofil, Gammaprofil);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  handle_Settings2();
} // handle_Gammaprofil1
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Gammaprofil2()
{
  Gammaprofil = 1;
  EEPROM.put(EepromAddrGammaprofil, Gammaprofil);
  EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  handle_Settings2();
} // handle_Gammaprofil1
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_LedTestNext()
{
  if (LedTestAktiv < 4)
  {
    LedTestAktiv = LedTestAktiv + 1;
  }
  else
  {
    {
      LedTestAktiv = 1;
    }
  }
  handle_Settings1();
} // handle_LedTestNext
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_LedTestAus()
{
  LedTestAktiv = 0;
  handle_Settings1();
} // handle_LedTestAus
/*
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████     █████   █████   █           █████     ██████    █████   ███████████     ██████        ███           ██████████████████
███████  ██   ███   █████   █████   ███████   ████   ███  █   ███   █████████   ████   ███   ████   █████   ██████████████████████
███████  ███   ██   █████   █████   █████   ████████   █   █   ██   ███████   ████████   █   ████   █████   ██████████████████████
███████      ████   █████   █████   █████   ████████   █   ██   █   ███████   ████████   █        ███████   ██████████████████████
███████  ████   █   █████   █████   █████   ████████   █   ███  █   ███████   ████████   █   ████████████   ██████████████████████
███████  █████  █   █████   █████   ███████   █████   ██   ████  █  █████████   █████   ██   ████████████   ██████████████████████
███████    █   ████      ████████   █████████     ██████   ██████   ███████████     ██████   ████████████   ██████████████████████
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
██████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void LedNrAktualisierenSet()
{
  AlleEditModeVerlassen();
  handle_Settings1();
} // LedNrAktualisierenProg
//▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀▄▀
void handle_Parametrieren()
{
  LedMarkieren();
  BuildParameterSite();
} // handle_Parametrieren
/*
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
█████████████   ████████         █      ████████████████████████████████████████████████████████████████████████████████████████████████████
█████████████   ████████   ███████   ███   █████████████████████████████████████████████████████████████████████████████████████████████████
█████████████   ████████   ███████   ████   ████████████████████████████████████████████████████████████████████████████████████████████████
█████████████   ████████       ███   ████   ████████████████████████████████████████████████████████████████████████████████████████████████
█████████████   ████████   ███████   ████   ████████████████████████████████████████████████████████████████████████████████████████████████
█████████████   ████████   ███████   ███   █████████████████████████████████████████████████████████████████████████████████████████████████
█████████████          █         █      ████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void TV()
{
  for (TVNr = 0; TVNr < AnzahlTV; TVNr++)
  {
    switch (PhaseNrTV[TVNr])
    {
    //■■ Phase wählen ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 0:
      TvSchrittInit[TVNr] = true;
      i = random(0, 100);      // 0...100%
      if (i < ChanceNeu[TVNr]) // Andere Farbe
      {
        HSV2ToHSV1TV(TVNr);
        i = random(0, 100);       // 0...100%
        if (i < ChanceBunt[TVNr]) // Bunte Farbe
        {
          Hue2TV[TVNr] = random(HueSpektrum);
          Sat2TV[TVNr] = random(SatBuntVon, SatBuntBis);
          Val2TV[TVNr] = random(150, 255);
        }
        else // Matte Farbe
        {
          Hue2TV[TVNr] = random(HueSpektrum);
          Sat2TV[TVNr] = random(SatMattVon, SatMattBis);
          Val2TV[TVNr] = random(150, 255);
        }
      }
      else // Gleiche Farbe
      {
        HSV2ToHSV1TV(TVNr);
      }
      i = random(0, 100);              // 0...100%
      if (i < ChanceShiftDirekt[TVNr]) // Direkt zu neuer Farbe gleiten
      {
        PhaseNrTV[TVNr] = 1; // Direkt zu neuer Farbe gleiten
      }
      else if (i < (ChanceShiftDirekt[TVNr] + ChanceShiftUmweg[TVNr])) // Via Dunkel zu neuer Farbe gleiten.
      {
        PhaseNrTV[TVNr] = 2; // Via Dunkel zu neuer Farbe gleiten
      }
      else
      {
        PhaseNrTV[TVNr] = 3; // Direkt zu neuer Farbe springen
      }
      break;
    //■■■ Direkt zu neuer Farbe gleiten ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 1:
      if (TvSchrittInit[TVNr])
      {
        //== Initialisierung =========================================================================
        DelayTv[TVNr] = random(0.4 * Faktor, 1 * Faktor);
        DelayTvSaved[TVNr] = DelayTv[TVNr];
      }
      TvSchrittInit[TVNr] = false;
      //== Periodischer Code =======================================================================
      if (DelayTv[TVNr] > 0) // Warten
      {
        DelayTv[TVNr]--;
        HueTV[TVNr] = map(DelayTv[TVNr], DelayTvSaved[TVNr], 0, Hue1TV[TVNr], Hue2TV[TVNr]);
        SatTV[TVNr] = map(DelayTv[TVNr], DelayTvSaved[TVNr], 0, Sat1TV[TVNr], Sat2TV[TVNr]);
        ValTV[TVNr] = map(DelayTv[TVNr], DelayTvSaved[TVNr], 0, Val1TV[TVNr], Val2TV[TVNr]);
      }
      else // Warten Fertig
      {
        PhaseNrTV[TVNr] = 0;
      }
      break;
    //■■ Via Dunkel zu neuer Farbe gleiten ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 2:
      if (TvSchrittInit[TVNr])
      {
        //== Initialisierung =========================================================================
        DelayTv[TVNr] = random(0.4 * Faktor, 1 * Faktor);
        DelayTvSaved[TVNr] = DelayTv[TVNr];
        TvSchrittTeil2[TVNr] = false;
      }
      TvSchrittInit[TVNr] = false;
      //== Periodischer Code =======================================================================
      if (!TvSchrittTeil2[TVNr]) // Abdunklungsphase
      {
        if (DelayTv[TVNr] > 0) // Weiter Abdunkeln
        {
          DelayTv[TVNr]--;
          ValTV[TVNr] = map(DelayTv[TVNr], DelayTvSaved[TVNr], 0, Val1TV[TVNr], 0);
        }
        else // Abdunkeln Fertig
        {
          DelayTv[TVNr] = DelayTvSaved[TVNr];
          TvSchrittTeil2[TVNr] = true;
        }
      }
      else // Aufhellphase
      {
        if (DelayTv[TVNr] > 0) // Weiter Aufhellen
        {
          DelayTv[TVNr]--;
          HueTV[TVNr] = Hue2TV[TVNr];
          SatTV[TVNr] = Sat2TV[TVNr];
          ValTV[TVNr] = map(DelayTv[TVNr], DelayTvSaved[TVNr], 0, 0, Val2TV[TVNr]);
        }
        else // Warten Fertig
        {
          PhaseNrTV[TVNr] = 0;
        }
      }
      break;
    //■■ Direkt zu neuer Farbe springen und warten ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 3:
      if (TvSchrittInit[TVNr])
      {
        //== Initialisierung =========================================================================
        HueTV[TVNr] = Hue2TV[TVNr];
        SatTV[TVNr] = Sat2TV[TVNr];
        ValTV[TVNr] = Val2TV[TVNr];
        DelayTv[TVNr] = random(3 * Faktor, 6 * Faktor);
      }
      TvSchrittInit[TVNr] = false;
      //== Periodischer Code =======================================================================
      if (DelayTv[TVNr] > 0) // Weiter Warten
      {
        DelayTv[TVNr]--;
      }
      else // Warten Fertig
      {
        PhaseNrTV[TVNr] = 0;
      }
      break;
    //■■ Default ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    default:
      // nichts
      break;
    }
  }
} // TV
/*
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████           █   █████████   ██████████████████████████████████████████████████████████████████████████████████████████████████████
███████████   ██████   ███████   ███████████████████████████████████████████████████████████████████████████████████████████████████████
███████████   ███████   █████   ████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████   ████████   ███   █████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████   █████████   █   ██████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████   ██████████     ███████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████   ███████████   ████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void LED(uint8_t Led, uint8_t Phase)
/*
      Led: Anzusteuernde LED  beginned mit 0

   Farbe : 0 = Aus
           1 = Ro
           2 = Or
           3 = Ge
           4 = Lim
           5 = Gr
           6 = Tü
           7 = Cy
           8 = Bl
           9 = Lil
           10 = Ma
           11 = Pi
           12 = Ki
           15 = Wie -1
           16 = -2
           17 = -3
           18 = -4
           20 = WaW
           21 = KaW
           22 = NeW
           25 = TV1
           26 = TV2
           27 = TV3
  */

{
  if (PhaseAlt[Led] != Phase) // Phase hat gewechselt
  {
    Schritt[Led] = 0;      // Schritt zurücksetzen
    PhaseAlt[Led] = Phase; // Phase merken
  }

  switch (Farbe[Led][Phase]) // Farbe wählen
  {
    //■■■■ Aus ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 0: // Aus
    ColorRoh[Led] = 0;
    EffektAnwenden = false; // Effekt nicht anwenden
    break;

    //■■■■ rot ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 1: // rot
    Hue1[Led] = HueRot;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ orange ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 2: // orange
    Hue1[Led] = HueOrange;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ gelb ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 3: // gelb
    Hue1[Led] = HueGelb;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ limette ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 4: // limette
    Hue1[Led] = HueLimette;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ grün ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■�����■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 5: // grün
    Hue1[Led] = HueGruen;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ türkis ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 6: // türkis
    Hue1[Led] = HueTuerkis;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ cyan ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 7: // cyan
    Hue1[Led] = HueCyan;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ blau ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 8: // blau
    Hue1[Led] = HueBlau;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ lila ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 9: // lila
    Hue1[Led] = HueLila;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ magenta ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 10: // magenta
    Hue1[Led] = HueMagenta;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ pink ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 11: // pink
    Hue1[Led] = HuePink;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ kirschrot ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 12: // kirschrot
    Hue1[Led] = HueKirschrot;
    Sat1[Led] = UintMax;
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■■ Wie -1 ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 15:        // Wie Vorgänger
    if (Led == 0) // Wenn kein Vorgänger (ist erste LED)
    {
      ColorRoh[Led] = 0;
    }
    else // hat Vorgänger
    {
      ColorRoh[Led] = ColorRoh[Led - 1];
    }
    EffektAnwenden = false; // Effekt nicht anwenden
    break;

    //■■■■■ -2 ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 16:        // Wie Vor-Vorgänger
    if (Led <= 1) // Wenn kein Vor-Vorgänger vorhanden
    {
      ColorRoh[Led] = 0;
    }
    else // hat Vorgänger
    {
      ColorRoh[Led] = ColorRoh[Led - 2];
    }
    EffektAnwenden = false; // Effekt nicht anwenden
    break;

    //■■■■■ -3 ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 17:        // Wie Vor-Vor-Vorgänger
    if (Led <= 2) // Wenn kein Vor-Vor-Vorgänger vorhanden
    {
      ColorRoh[Led] = 0;
    }
    else // hat Vorgänger
    {
      ColorRoh[Led] = ColorRoh[Led - 3];
    }
    EffektAnwenden = false; // Effekt nicht anwenden
    break;

    //■■■■■ -4 ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 18:        // Wie Vor-Vor-Vor-Vorgänger
    if (Led <= 3) // Wenn kein Vor-Vor-Vor-Vorgänger vorhanden
    {
      ColorRoh[Led] = 0;
    }
    else // hat Vorgänger
    {
      ColorRoh[Led] = ColorRoh[Led - 4];
    }
    EffektAnwenden = false; // Effekt nicht anwenden
    break;

    //■■■■ Warmweiss ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 20: // Warmweiss
    Hue1[Led] = WarmweissHue[Gammaprofil];
    Sat1[Led] = WarmweissSat[Gammaprofil];
    EffektAnwenden = true;
    break;

    //■■■ Kaltweiss ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 21: // Kaltweiss
    Hue1[Led] = KaltweissHue[Gammaprofil];
    Sat1[Led] = KaltweissSat[Gammaprofil];
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■ Neutralweiss ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 22: // Neutralweiss
    Hue1[Led] = NeutralweissHue[Gammaprofil];
    Sat1[Led] = NeutralweissSat[Gammaprofil];
    EffektAnwenden = true; // Effekt anwenden
    break;

    //■■■■ TV1 ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 25: // TV1
    rgb = stripWS2812.gamma32(stripWS2812.ColorHSV(HueTV[0], SatTV[0], ValTV[0]));
    r = (rgb >> 16);
    r = r * HelligkeitVal[Helligkeit[Led][Phase]] / UintMax;
    g = (rgb >> 8);
    g = g * HelligkeitVal[Helligkeit[Led][Phase]] / UintMax;
    b = (rgb);
    b = b * HelligkeitVal[Helligkeit[Led][Phase]] / UintMax;
    ColorRoh[Led] = (r << 16) + (g << 8) + b;
    EffektAnwenden = false; // Effekt nicht anwenden
    break;                  // TV

    //■■■■ TV2 ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 26: // TV2
    rgb = stripWS2812.gamma32(stripWS2812.ColorHSV(HueTV[1], SatTV[1], ValTV[1]));
    r = (rgb >> 16);
    r = r * HelligkeitVal[Helligkeit[Led][Phase]] / UintMax;
    g = (rgb >> 8);
    g = g * HelligkeitVal[Helligkeit[Led][Phase]] / UintMax;
    b = (rgb);
    b = b * HelligkeitVal[Helligkeit[Led][Phase]] / UintMax;
    ColorRoh[Led] = (r << 16) + (g << 8) + b;
    EffektAnwenden = false; // Effekt nicht anwenden
    break;                  // TV

    //■■■■ TV3 ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  case 27: // TV3
    rgb = stripWS2812.gamma32(stripWS2812.ColorHSV(HueTV[2], SatTV[2], ValTV[2]));
    r = (rgb >> 16);
    r = r * HelligkeitVal[Helligkeit[Led][Phase]] / UintMax;
    g = (rgb >> 8);
    g = g * HelligkeitVal[Helligkeit[Led][Phase]] / UintMax;
    b = (rgb);
    b = b * HelligkeitVal[Helligkeit[Led][Phase]] / UintMax;
    ColorRoh[Led] = (r << 16) + (g << 8) + b;
    EffektAnwenden = false; // Effekt nicht anwenden
    break;                  // TV

    //■■■■ Default ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  default:
    ColorRoh[Led] = 0;      // Aus
    EffektAnwenden = false; // Effekt nicht anwenden
    break;
  } // Ende Switch Farben

  /*
  Effekte: 0 = C Konstant
           1 = LS1 Leuchtstoff  Einschaltflackern
           2 = Ls2 Leuchstoff Dauerflackern
           3 = Feu1 Feuer ruhiger
           4 = Feu2 Feuer lebhafter    
           5 = WK1 Wackelkontakt ruhiger
           6 = WK2 Wackelkontakt mittel
           7 = WK2 Wackelkontakt lebhafter
  */

  if (EffektAnwenden) // Wenn Effekt angewendet werden soll
  {
    switch (Effekt[Led][Phase]) // Effekt wählen
    {
    //■■■■ C Konstant ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 0: // Konstant
      ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], (HelligkeitVal[Helligkeit[Led][Phase]]));
      break;

    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■ LS1 Leuchtstoff  Einschaltflackern ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 1: // LS1 Leuchtstoff  Einschaltflackern
      switch (Schritt[Led])
      {
      //=======================================================================================
      // Phase 0: Initialisieren
      case 0:
        DelayLed[Led] = random((uint8_t)(NeonZeitHalbhellEinschaltMin * Faktor), (uint8_t)(NeonZeitHalbhellEinschaltMax * Faktor));
        SchrittTimer[Led] = 0;   // Zaehler zurücksetzen
        FlackerZaehler[Led] = 0; // Flackerzähler Zurücksetzen
        FlackerZyklen[Led] = random(FlackerZyklenMax, FlackerZyklenMin);
        Schritt[Led] = 1; // Nächster Schritt
        break;
      //=======================================================================================
      // Schritt 1: Halbhell
      case 1:
        SchrittAlt[Led] = 1;
        SchrittTimer[Led]++;
        if (SchrittTimer[Led] < DelayLed[Led]) // Verzögerungszeit läuft
        {
          SchrittTimer[Led]++;
          ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], (NeonValHalbhell[Helligkeit[Led][Phase]]));
        }
        else // Verzögerung abgelaufen
        {
          SchrittTimer[Led] = 0;
          DelayLed[Led] = random((uint8_t)(NeonZeitImpulsEinschaltMin * Faktor), (uint8_t)(NeonZeitImpulsEinschaltMax * Faktor));
          Schritt[Led] = 2; // Nächster Schritt
        }
        break;
      //=======================================================================================
      // Schritt 2: Voller Impuls abschwellend
      case 2:
        SchrittTimer[Led]++;
        if (SchrittTimer[Led] < DelayLed[Led]) // Verzögerungszeit läuft
        {
          SchrittTimer[Led]++;
          Val[Led] = map(SchrittTimer[Led], 0, DelayLed[Led], HelligkeitVal[Helligkeit[Led][Phase]], (NeonValHalbhell[Helligkeit[Led][Phase]]));
          ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], Val[Led]);
        }
        else // Verzögerung abgelaufen
        {
          SchrittTimer[Led] = 0;
          DelayLed[Led] = random((uint8_t)(NeonZeitHalbhellEinschaltMin * Faktor), (uint8_t)(NeonZeitHalbhellEinschaltMax * Faktor));
          FlackerZaehler[Led]++;
          if (FlackerZaehler[Led] >= FlackerZyklen[Led])
          {
            Schritt[Led] = 3; // Nächster Schritt
          }
          else
          {
            Schritt[Led] = 1; // Voriger Schritt
          }
        }
        break;
      //=======================================================================================
      // Schritt 3: Permanent eingeschaltet
      case 3:
        if (SchrittAlt[Led] != 3)
        {
          ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], HelligkeitVal[Helligkeit[Led][Phase]]); // Warmweiss
          SchrittAlt[Led] = 3;
        }
        break;
      }
      break; // Ende LS1 Leuchtstoff  Einschaltflackern

    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■ Ls2 Leuchstoff Dauerflackern ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 2: //  Ls2 Leuchstoff Dauerflackern
      switch (Schritt[Led])
      {
        //=======================================================================================
        // Phase 0: Initialisieren
      case 0:
        SchrittAlt[Led] = 0;
        DelayLed[Led] = random((uint8_t)(NeonZeitHalbhellDauerMin * Faktor), (uint8_t)(NeonZeitHalbhellDauerMax * Faktor));
        SchrittTimer[Led] = 0;   // Zaehler zurücksetzen
        FlackerZaehler[Led] = 0; // Flackerzähler Zurücksetzen
        FlackerZyklen[Led] = random(FlackerZyklenMax, FlackerZyklenMin);
        Schritt[Led] = 1; // Nächstre Schritt
        break;
      //=======================================================================================
      // Phase 1: Halbhell
      case 1:
        SchrittAlt[Led] = 1;
        SchrittTimer[Led]++;
        if (SchrittTimer[Led] < DelayLed[Led]) // Verzögerungszeit läuft
        {
          SchrittTimer[Led]++;
          ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], (NeonValHalbhell[Helligkeit[Led][Phase]]));
        }
        else // Verzögerung abgelaufen
        {
          SchrittTimer[Led] = 0;
          DelayLed[Led] = random((uint8_t)(NeonZeitImpulsDauerMin * Faktor), (uint8_t)(NeonZeitImpulsDauerMax * Faktor));
          Schritt[Led] = 2; // Nächster Schritt
        }
        break;
      //=======================================================================================
      // Phase 2: Voller Impuls abschwellend
      case 2:
        SchrittTimer[Led]++;
        if (SchrittTimer[Led] < DelayLed[Led]) // Verzögerungszeit läuft
        {
          SchrittTimer[Led]++;
          Val[Led] = map(SchrittTimer[Led], 0, DelayLed[Led], HelligkeitVal[Helligkeit[Led][Phase]], (NeonValHalbhell[Helligkeit[Led][Phase]]));
          ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], Val[Led]);
        }
        else // Verzögerung abgelaufen
        {
          SchrittTimer[Led] = 0;
          DelayLed[Led] = random((uint8_t)(NeonZeitHalbhellDauerMin * Faktor), (uint8_t)(NeonZeitHalbhellDauerMax * Faktor));
          Schritt[Led] = 1; // Voriger Schritt
        }
        break;
      }
      break; // Ende Ls2 Leuchstoff Dauerflackern

    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■ Feu1 Feuer ruhiger ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 3: // Feu1 Feuer ruhiger
      switch (Schritt[Led])
      {
      //=======================================================================================
      case 0: //Initialisieren
        Sat1[Led] = FeuerSat[Helligkeit[Led][Phase]]; // Helligkeit (permanent)
        Val2[Led] = 0;                                // Dunkel als (Startwert)
        Schritt[Led] = 1;
        break;
      //=======================================================================================
      case 1: // Neues zufälliges Helligkeitsziel und neue Dauer
        SchrittTimer[Led] = 0;
        DelayLed[Led] = random(Feuer1DelayMin * Faktor, Feuer1DelayMax * Faktor);
        Val1[Led] = Val2[Led];
        Val2[Led] = random(Feuer1ValMin[Helligkeit[Led][Phase]], Feuer1ValMax[Helligkeit[Led][Phase]]);
        // ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], Val1[Led]);
        Schritt[Led] = 2;
        break;
      //=======================================================================================
      case 2: // Farbe driften
        SchrittTimer[Led]++;
        Val[Led] = map(SchrittTimer[Led], 0, DelayLed[Led], Val1[Led], Val2[Led]);
        ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], Val[Led]);
        if (SchrittTimer[Led] >= DelayLed[Led]) // Verzögerungszeit läuft
        {
          Schritt[Led] = 1;
        }
        break;
        //=======================================================================================
      }
      break; // Ende Feu1 Feuer ruhiger

    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■ Feu2 Feuer lebhafter ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 4: // Feu2 Feuer lebhafter
      switch (Schritt[Led])
      {
      //=======================================================================================
      case 0: //Initialisieren
        Sat1[Led] = FeuerSat[Helligkeit[Led][Phase]]; // Helligkeit (permanent)
        Val2[Led] = 0;                                // Dunkel als (Startwert)
        Schritt[Led] = 1;
        break;
      //=======================================================================================
      case 1: // Neues zufälliges Helligkeitsziel und neue Dauer
        SchrittTimer[Led] = 0;
        DelayLed[Led] = random(Feuer2DelayMin * Faktor, Feuer2DelayMax * Faktor);
        Val1[Led] = Val2[Led];
        Val2[Led] = random(Feuer2ValMin[Helligkeit[Led][Phase]], Feuer2ValMax[Helligkeit[Led][Phase]]);
        // ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], Val1[Led]);
        Schritt[Led] = 2;
        break;
      //=======================================================================================
      case 2: // Farbe driften
        SchrittTimer[Led]++;
        Val[Led] = map(SchrittTimer[Led], 0, DelayLed[Led], Val1[Led], Val2[Led]);
        ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], Val[Led]);
        if (SchrittTimer[Led] >= DelayLed[Led]) // Verzögerungszeit läuft
        {
          Schritt[Led] = 1;
        }
        break;
        //=======================================================================================
      }
      break; // Ende Feu2 Feuer lebhafter

    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■ WK1 Wackelkontakt ruhiger ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 5: // WK1 Wackelkontakt ruhiger
      switch (Schritt[Led])
      {
      //=======================================================================================
      // Phase 0: Dauerlicht vorbereiten
      case 0:
        DelayLed[Led] = random((int)(WK1PauseMin * Faktor), (int)(WK1PauseMax * Faktor));
        Schritt[Led] = 1;
        break;
      //=======================================================================================
      // Schritt 1: Dauerlicht
      case 1:
        if (DelayLed[Led] > 0) // Verzögerungszeit läuft
        {
          DelayLed[Led]--;
          ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], (HelligkeitVal[Helligkeit[Led][Phase]]));
        }
        else // Verzögerung abgelaufen
        {
          Schritt[Led] = 2;
        }
        break;
        //=======================================================================================
      // Schritt 2: Flackern vorbereiten
      case 2:
        FlackerZaehler[Led] = random(WK1ZyklenMin, WK1ZyklenMax);
        Schritt[Led] = 3; // Nächster Schritt
        break;
        //=======================================================================================
      // Schritt 3: Flackerphase ausführen
      case 3:
        Val[Led] = random(HelligkeitValWackel[Helligkeit[Led][Phase]], HelligkeitVal[Helligkeit[Led][Phase]]);
        ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], Val[Led]);
        FlackerZaehler[Led]--;
        if (FlackerZaehler[Led] <= 0) // Flackern beendet
        {
          Schritt[Led] = 0; // Dauerlicht vorbereiten
        }
        break;
        //=======================================================================================
      }
      break; // Ende WK1 Wackelkontakt ruhiger

    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■ WK2 Wackelkontakt lebhafter ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 6: // WK2 Wackelkontakt lebhafter
      switch (Schritt[Led])
      {
      //=======================================================================================
      // Phase 0: Dauerlicht vorbereiten
      case 0:
        DelayLed[Led] = random((int)(WK2PauseMin * Faktor), (int)(WK2PauseMax * Faktor));
        Schritt[Led] = 1;
        break;
      //=======================================================================================
      // Schritt 1: Dauerlicht
      case 1:
        if (DelayLed[Led] > 0) // Verzögerungszeit läuft
        {
          DelayLed[Led]--;
          ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], (HelligkeitVal[Helligkeit[Led][Phase]]));
        }
        else // Verzögerung abgelaufen
        {
          Schritt[Led] = 2;
        }
        break;
        //=======================================================================================
      // Schritt 2: Flackern vorbereiten
      case 2:
        FlackerZaehler[Led] = random(WK2ZyklenMin, WK2ZyklenMax);
        Schritt[Led] = 3; // Nächster Schritt
        break;
        //=======================================================================================
      // Schritt 3: Flackerphase ausführen
      case 3:
        Val[Led] = random(HelligkeitValWackel[Helligkeit[Led][Phase]], HelligkeitVal[Helligkeit[Led][Phase]]);
        ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], Val[Led]);
        FlackerZaehler[Led]--;
        if (FlackerZaehler[Led] <= 0) // Flackern beendet
        {
          Schritt[Led] = 0; // Dauerlicht vorbereiten
        }
        break;
        //=======================================================================================
      }
      break; // Ende WK2 Wackelkontakt lebhafter

    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■ WK3 Wackelkontakt lebhaft ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    case 7: // WK3 Wackelkontakt lebhaft
      switch (Schritt[Led])
      {
      //=======================================================================================
      // Phase 0: Dauerlicht vorbereiten
      case 0:
        DelayLed[Led] = random((int)(WK3PauseMin * Faktor), (int)(WK3PauseMax * Faktor));
        Schritt[Led] = 1;
        break;
      //=======================================================================================
      // Schritt 1: Dauerlicht
      case 1:
        if (DelayLed[Led] > 0) // Verzögerungszeit läuft
        {
          DelayLed[Led]--;
          ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], (HelligkeitVal[Helligkeit[Led][Phase]]));
        }
        else // Verzögerung abgelaufen
        {
          Schritt[Led] = 2;
        }
        break;
        //=======================================================================================
      // Schritt 2: Flackern vorbereiten
      case 2:
        FlackerZaehler[Led] = random(WK3ZyklenMin, WK3ZyklenMax);
        Schritt[Led] = 3; // Nächster Schritt
        break;
        //=======================================================================================
      // Schritt 3: Flackerphase ausführen
      case 3:
        Val[Led] = random(HelligkeitValWackel[Helligkeit[Led][Phase]], HelligkeitVal[Helligkeit[Led][Phase]]);
        ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], Val[Led]);
        FlackerZaehler[Led]--;
        if (FlackerZaehler[Led] <= 0) // Flackern beendet
        {
          Schritt[Led] = 0; // Dauerlicht vorbereiten
        }
        break;
        //=======================================================================================
      }
      break; // Ende WK3 Wackelkontakt lebhaft

    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■ Default Effekt ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    default: // Konstant
      ColorRoh[Led] = stripWS2812.ColorHSV(Hue1[Led], Sat1[Led], (HelligkeitVal[Helligkeit[Led][Phase]]));
      break;
    } // Ende Switch Effekte
  }   // EndIf Effekt anwenden

  //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  //■■■■ Gamma verrechnen, dann Led Parametrieren ■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
  if (Led < AnzahlPL9823Benutzt) // Ist PL9823 --> Gamma und Parametrierung für PL9823
  {
    if ((Farbe[Led][Phase] == 31) || (Farbe[Led][Phase] == 32) || (Farbe[Led][Phase] == 33)) // Sonder-Gamma für Weisstöne
    {
      r = (ColorRoh[Led] >> 16);
      r = Gamma(r, GammaRp[Gammaprofil], MaxRp);
      g = (ColorRoh[Led] >> 8);
      g = Gamma(g, GammaGp[Gammaprofil], MaxGp);
      b = (ColorRoh[Led]);
      b = Gamma(b, GammaBp[Gammaprofil], MaxBp);
      ColorGamma[Led] = (r << 16) + (g << 8) + b;
    }
    else // Einfaches Gamma für restliche Farben für beide LED-Typen
    {
      ColorGamma[Led] = stripWS2812.gamma32(ColorRoh[Led]);
    }
    stripPL9823.setPixelColor(Led, ColorGamma[Led]); // LED parametrieren
  }
  else // Ist WS2812 --> Gamma und Parametrierung für WS2812
  {
    if ((Farbe[Led][Phase] == 31) || (Farbe[Led][Phase] == 32) || (Farbe[Led][Phase] == 33)) // Sonder-Gamma für Weisstöne
    {
      r = (ColorRoh[Led] >> 16);
      r = Gamma(r, GammaRw, MaxRw[Gammaprofil]);
      g = (ColorRoh[Led] >> 8);
      g = Gamma(g, GammaGw, MaxGw[Gammaprofil]);
      b = (ColorRoh[Led]);
      b = Gamma(b, GammaBw, MaxBw[Gammaprofil]);
      ColorGamma[Led] = (r << 16) + (g << 8) + b;
    }
    else // Einfaches Gamma für restliche Farben für beide LED-Typen
    {
      ColorGamma[Led] = stripWS2812.gamma32(ColorRoh[Led]);
    }
    stripWS2812.setPixelColor(Led - AnzahlPL9823Benutzt, ColorGamma[Led]); // LED parametrieren
  }
} // LED
/*
█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
█████████      ███        █   █         █    █████   █         ██████████████████████████████████████████████████████████████████████████████
███████   ████   ████████   ███   ███████  █   ███   █   ████████████████████████████████████████████████████████████████████████████████████
████████   █████████████   ████   ███████   █   ██   █   ████████████████████████████████████████████████████████████████████████████████████
██████████   █████████   ██████       ███   ██   █   █       ████████████████████████████████████████████████████████████████████████████████
█████████████   █████   ███████   ███████   ███  █   █   ████████████████████████████████████████████████████████████████████████████████████
███████   ████   ██   █████████   ███████   ████  █  █   ████████████████████████████████████████████████████████████████████████████████████
█████████      ███            █         █   ██████   █         ██████████████████████████████████████████████████████████████████████████████
█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
█████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void Szene()
{
  for (LedZaehler = 0; LedZaehler < AnzahlLedBenutzt; LedZaehler++)
  { // Für jede LED
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    if (LedInEditMode[LedZaehler] == 1) // Led im Edit Mode
    {
      LedInEditModeAlt[LedZaehler] = LedInEditMode[LedZaehler]; // Altwert Edit Mode merken
      LED(LedZaehler, PhasenAnzahl[LedZaehler]);
    }
    else if (LedInCopyMode[LedZaehler] == 1)
    {
      if (isPL9823(LedZaehler))
      {
        stripPL9823.setPixelColor(LedZaehler, UintMax, UintMax, UintMax);
      }
      else
      {
        stripWS2812.setPixelColor(LedZaehler - AnzahlPL9823Benutzt, UintMax, UintMax, UintMax);
      }
    }
    //■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■
    else // Led in Run (nicht im Edit Mode)
    {
      if ((LedInEditModeAlt[LedZaehler] != LedInEditMode[LedZaehler]) || SzenarioRestart) // Szene wechselte vom Edit Mode zu Run (initialisieren) oder Szenario neustart
      {
        LedInEditModeAlt[LedZaehler] = LedInEditMode[LedZaehler]; // Altwert Edit Mode merken
        PhasenTimer[LedZaehler] = 0;                              // Phasentimer zurücksetzen
        PhaseZeit[LedZaehler] = Zeit(Zeitwahl[LedZaehler][0]);    // Erste Phasenzeit laden
        Phase[LedZaehler] = 0;                                    // Aufuf erste Phase setzen
      }
      else // Szene läuft
      {
        if (PhasenAnzahl[LedZaehler] > 0) // Szene hat mehr als eine Phase
        {
          PhasenTimer[LedZaehler]++;
          if (PhasenTimer[LedZaehler] >= PhaseZeit[LedZaehler]) // Phasenzeit abgelaufen
          {
            PhasenTimer[LedZaehler] = 0;                       // Timer zurücksetzen
            if (Phase[LedZaehler] >= PhasenAnzahl[LedZaehler]) // Wenn Anzahl Phasen durchlaufen sind
            {
              Phase[LedZaehler] = 0; // Erste Phase wählen
            }
            else // nächsten Phasenplatz wählen
            {
              Phase[LedZaehler]++; // Nächste Phase wählen
            }
            PhaseZeit[LedZaehler] = Zeit(Zeitwahl[LedZaehler][Phase[LedZaehler]]); // Neue Phasenzeit laden
          }
        }
      }
      LED(LedZaehler, Phase[LedZaehler]);
    }
  }
  stripWS2812.show();      // WS2812 anzeigen
  stripPL9823.show();      // PL9823 anzeigen
  SzenarioRestart = false; // Flag für Szenario Neustart zurücksetzen
} // Szene
/*
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████████████      ███         █           █   █████   █        ██████████████████████████████████████████████████
█████████████   ████   █   ███████████   █████   █████   █   ████   ████████████████████████████████████████████████
██████████████   ███████   ███████████   █████   █████   █   ████   ████████████████████████████████████████████████
████████████████   █████       ███████   █████   █████   █        ██████████████████████████████████████████████████
███████████████████   ██   ███████████   █████   █████   █   ███████████████████████████████████████████████████████
█████████████   ████   █   ███████████   █████   █████   █   ███████████████████████████████████████████████████████
███████████████      ███         █████   ███████      ████   ███████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void setup()
{
  Serial.begin(115200);
  delay(200);

  pinMode(PirSensor, INPUT);  //PIR Sensor as input
  pinMode(Kontakt, INPUT_PULLUP);  //Kontakt Eingang
  pinMode(BeleuchtungAktiv1, OUTPUT);  // Beleuchtung Aktiv = 1
  pinMode(BeleuchtungAktiv0, OUTPUT);  // Beleuchtung Aktiv = 0

  pinMode(Buzzer, OUTPUT);
  digitalWrite(Buzzer, HIGH);
  delay(200);
  digitalWrite(Buzzer, LOW);

  EEPROM.begin(4096);
  stripWS2812.begin();
  stripWS2812.show();                          // Turn OFF all pixels ASAP
  stripWS2812.setBrightness(Gesamthelligkeit); // Set BRIGHTNESS to about 1/5 (max = 255)
  stripPL9823.begin();
  stripPL9823.show();                          // Turn OFF all pixels ASAP
  stripPL9823.setBrightness(Gesamthelligkeit); // Set BRIGHTNESS to about 1/5 (max = 255)
  lastMillis1 = millis();

  EEPROM.get(EepromAddrDeviceNr, DeviceNr); //Devicenummer von EEprom lesen
  if ((DeviceNr > DeviceNrMax) || (DeviceNr < 1))
  {
    DeviceNr = 1;
    EEPROM.put(EepromAddrDeviceNr, DeviceNr);
    EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  }

  EEPROM.get(EepromAddrVersion, VersionGespeichert); //LDRLevel von EEprom lesen
  if ((VersionGespeichert < VersionMindest))
  {
    AllePhasenResetten();
    Save(0);
    Save(1);
    Save(2);
    Save(3);
    Save(4);
    Save(5);
  }

  EEPROM.get(EepromAddrEinschaltIndex, EinschaltIndex);
  if ((EinschaltIndex > EinschaltTimerMax) || (EinschaltIndex < 0))
  {
    EinschaltIndex = 0;
    EEPROM.put(EepromAddrEinschaltIndex, EinschaltIndex);
  }

  EEPROM.get(EepromAddrGammaprofil, Gammaprofil);
  if ((Gammaprofil > GammaprofilMax) || (Gammaprofil < 0))
  {
    Gammaprofil = 0;
    EEPROM.put(EepromAddrGammaprofil, Gammaprofil);
  }
  ZeitEin(EinschaltIndex);

  if ((VersionGespeichert != VersionAktuell))
  {
    EEPROM.put(EepromAddrVersion, VersionAktuell);
    EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  }

  EEPROM.get(EepromAddrAnzahlWS2812, AnzahlWS2812Benutzt); //Anzahl Benutzte LED von EEprom lesen
  EEPROM.get(EepromAddrAnzahlPL9823, AnzahlPL9823Benutzt); //Anzahl Benutzte LED von EEprom lesen
  EEPROM.get(EepromAddrAnzahlLED, AnzahlLedBenutzt);       //Anzahl Benutzte LED von EEprom lesen
  if ((AnzahlLedBenutzt > (AnzahlLedMax)) || (AnzahlLedBenutzt < 0) || (AnzahlLedBenutzt != (AnzahlWS2812Benutzt + AnzahlPL9823Benutzt)))
  {
    AnzahlWS2812Benutzt = 0;
    EEPROM.put(EepromAddrAnzahlWS2812, AnzahlWS2812Benutzt);
    AnzahlPL9823Benutzt = 0;
    EEPROM.put(EepromAddrAnzahlPL9823, AnzahlPL9823Benutzt);
    AnzahlLedBenutzt = 0;
    EEPROM.put(EepromAddrAnzahlLED, AnzahlLedBenutzt);
    EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  }
  stripWS2812.updateLength(AnzahlWS2812Benutzt);
  stripPL9823.updateLength(AnzahlPL9823Benutzt);

  EEPROM.get(EepromAddrLDRLevel, LDRLevel); //LDRLevel von EEprom lesen
  if ((LDRLevel > 4) || (LDRLevel < 0))
  {
    LDRLevel = 0;
    EEPROM.put(EepromAddrLDRLevel, LDRLevel);
    EEPROM.commit(); // Eeprom-RAM ins Eeprom schreiben
  }

  for (i = 0; i < AnzahlLedMax; i++)
  {
    LedInEditMode[i] = 0;
  }

  IPAddress local_ip(192, 168, 1, DeviceNr);
  IPAddress gateway(192, 168, 1, 1);
  IPAddress subnet(255, 255, 255, 0);

  sprintf(ssid, "LumiScene%02d \n", DeviceNr);
  password = "12345678"; //Enter Password here

  WiFi.softAP(ssid, password);
  WiFi.softAPConfig(local_ip, gateway, subnet);
  delay(100);

  //Handler für Parameterseite...
  server.on("/", handle_Parameters);
  server.on("/LedPrev5Prog", handle_Waehe5LedMinus);
  server.on("/LedPrevProg", handle_Waehe1LedMinus);
  server.on("/LedNextProg", handle_Waehe1LedPlus);
  server.on("/LedNext5Prog", handle_Waehe5LedPlus);
  server.on("/Copy", handle_Copy);
  server.on("/ShowLED", handle_ShowLED);
  server.on("/AlleAus", handle_AlleLedAus);

  server.on("/WaehlePhasenAnzahl", handle_WaehlePhasenAnzahl);
  server.on("/SetProg1", handle_WaehlePhase1);
  server.on("/SetProg2", handle_WaehlePhase2);
  server.on("/SetProg3", handle_WaehlePhase3);
  server.on("/SetProg4", handle_WaehlePhase4);
  server.on("/SetProg5", handle_WaehlePhase5);
  server.on("/SetProg6", handle_WaehlePhase6);
  server.on("/SetProg7", handle_WaehlePhase7);
  server.on("/SetProg8", handle_WaehlePhase8);

  server.on("/Farbe00", handle_Farbe00);
  server.on("/Farbe01", handle_Farbe01);
  server.on("/Farbe02", handle_Farbe02);
  server.on("/Farbe03", handle_Farbe03);
  server.on("/Farbe04", handle_Farbe04);
  server.on("/Farbe05", handle_Farbe05);
  server.on("/Farbe06", handle_Farbe06);
  server.on("/Farbe07", handle_Farbe07);
  server.on("/Farbe08", handle_Farbe08);
  server.on("/Farbe09", handle_Farbe09);
  server.on("/Farbe10", handle_Farbe10);
  server.on("/Farbe11", handle_Farbe11);
  server.on("/Farbe12", handle_Farbe12);
  server.on("/Farbe15", handle_Farbe15);
  server.on("/Farbe16", handle_Farbe16);
  server.on("/Farbe17", handle_Farbe17);
  server.on("/Farbe18", handle_Farbe18);
  server.on("/Farbe20", handle_Farbe20);
  server.on("/Farbe21", handle_Farbe21);
  server.on("/Farbe22", handle_Farbe22);
  server.on("/Farbe25", handle_Farbe25);
  server.on("/Farbe26", handle_Farbe26);
  server.on("/Farbe27", handle_Farbe27);

  server.on("/Effekt00", handle_Effekt00);
  server.on("/Effekt01", handle_Effekt01);
  server.on("/Effekt02", handle_Effekt02);
  server.on("/Effekt03", handle_Effekt03);
  server.on("/Effekt04", handle_Effekt04);
  server.on("/Effekt05", handle_Effekt05);
  server.on("/Effekt06", handle_Effekt06);
  server.on("/Effekt07", handle_Effekt07);

  server.on("/Time0k", handle_Time0k);
  server.on("/Time1k", handle_Time1k);
  server.on("/Time2k", handle_Time2k);
  server.on("/Time3k", handle_Time3k);
  server.on("/Time4k", handle_Time4k);
  server.on("/Time5k", handle_Time5k);
  server.on("/Time6k", handle_Time6k);
  server.on("/Time7k", handle_Time7k);
  server.on("/Time8k", handle_Time8k);
  server.on("/Time9k", handle_Time9k);
  server.on("/Time0z", handle_Time0z);
  server.on("/Time1z", handle_Time1z);
  server.on("/Time2z", handle_Time2z);
  server.on("/Time3z", handle_Time3z);
  server.on("/Time4z", handle_Time4z);
  server.on("/Time5z", handle_Time5z);
  server.on("/Time6z", handle_Time6z);
  server.on("/Time7z", handle_Time7z);

  server.on("/Hell1", handle_Hell1);
  server.on("/Hell2", handle_Hell2);
  server.on("/Hell3", handle_Hell3);
  server.on("/Settings1", handle_Settings1);
  server.on("/LegendeProg", handle_LegendeProg);

  //Handler für Settingsseite...
  server.on("/DevNrDefault", handle_DeviceNrDefault);
  server.on("/DevNrUp", handle_DeviceNrAddrUp);
  server.on("/DevNrUp10", handle_DeviceNrAddrUp10);
  server.on("/DevNrSet", handle_DeviceNrAktivieren);
  server.on("/AnzPL9823Reset", handle_AnzahlPL9823Reset);
  server.on("/AnzPL9823Erhoehen", handle_AnzahlPL9823Erhoehen);
  server.on("/AnzPL9823Erhoehen5", handle_AnzahlPL9823Erhoehen5);
  server.on("/AnzWS2812Reset", handle_AnzahlWS2812Reset);
  server.on("/AnzWS2812Erhoehen", handle_AnzahlWS2812Erhoehen);
  server.on("/AnzWS2812Erhoehen5", handle_AnzahlWS2812Erhoehen5);
  server.on("/Gammaprofil1", handle_Gammaprofil1);
  server.on("/Gammaprofil2", handle_Gammaprofil2);
  server.on("/LedTestNext", handle_LedTestNext);
  server.on("/LedTestAus", handle_LedTestAus);

  server.on("/Eingeschaltet0", handle_Eingeschaltet0);
  server.on("/Eingeschaltet6", handle_Eingeschaltet6);
  server.on("/Eingeschaltet5", handle_Eingeschaltet5);
  server.on("/Eingeschaltet4", handle_Eingeschaltet4);
  server.on("/Eingeschaltet3", handle_Eingeschaltet3);
  server.on("/Eingeschaltet2", handle_Eingeschaltet2);
  server.on("/Eingeschaltet1", handle_Eingeschaltet1);

  server.on("/Load1", handle_Load0);
  server.on("/Load2", handle_Load1);
  server.on("/Load3", handle_Load2);
  server.on("/Load4", handle_Load3);
  server.on("/Load5", handle_Load4);
  server.on("/Load6", handle_Load5);
  server.on("/Save1", handle_Save0);
  server.on("/Save2", handle_Save1);
  server.on("/Save3", handle_Save2);
  server.on("/Save4", handle_Save3);
  server.on("/Save5", handle_Save4);
  server.on("/Save6", handle_Save5);
  server.on("/Synchronisation", handle_Synchronisation);
  server.on("/ExportSD", handle_ExportSD);
  server.on("/ImportSD", handle_ImportSD);
  server.on("/Neustart", handle_Neustart);
  server.on("/Parameters", handle_Parameters);
  server.on("/Settings2", handle_Settings2);
  server.on("/LegendeSettings1", handle_LegendeSettings1);

  //Handle Server für Optionsseite 2
  server.on("/TimeEin0", handle_TimeEin0);
  server.on("/TimeEin1", handle_TimeEin1);
  server.on("/TimeEin2", handle_TimeEin2);
  server.on("/TimeEin3", handle_TimeEin3);
  server.on("/TimeEin4", handle_TimeEin4);
  server.on("/TimeEin5", handle_TimeEin5);
  server.on("/TimeEin6", handle_TimeEin6);
  server.on("/TimeEin7", handle_TimeEin7);
  server.on("/TimeEin8", handle_TimeEin8);
  server.on("/TimeEin9", handle_TimeEin9);
  server.on("/TimeEin10", handle_TimeEin10);
  server.on("/TimeEin11", handle_TimeEin11);
  server.on("/TimeEin12", handle_TimeEin12);
  server.on("/LegendeSettings2", handle_LegendeSettings2);


  server.begin();
  BuildParameterSite();
  LedTestAktiv = 0;
  Load(0); //Szenario 0 laden
} // Setup
/*
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
███████   ████████████     ██████████     ██████        ████████████████████████████████████████████████████████████████████████████████
███████   ██████████   ████   █████   ████   ███   ████   ██████████████████████████████████████████████████████████████████████████████
███████   ████████   ████████   █   ████████   █   ████   ██████████████████████████████████████████████████████████████████████████████
███████   ████████   ████████   █   ████████   █        ████████████████████████████████████████████████████████████████████████████████
███████   ████████   ████████   █   ████████   █   █████████████████████████████████████████████████████████████████████████████████████
███████   ██████████   █████   ████   █████   ██   █████████████████████████████████████████████████████████████████████████████████████
███████          █████     ██████████     ██████   █████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
*/
void loop()
{
  // unsigned long Periode; // ???
  digitalWrite(Buzzer, LOW);
  server.handleClient();
  if ((millis() - lastMillis1) >= Zyklus) // Zeittakt erreicht
  {
    lastMillis1 = millis();
    TV();    // Verarbeitete die Fernsehprogramme
    switch (LedTestAktiv)  //Entscheidung Normalbetrieb oder LED Test
    {
    case 0: // Normalbetrieb
      AusloeserAuswerten();
      LDRAuswerten();
      if (LDRTrigger && AusloeserTrigger) // Beleuchtung aktiv
      {
        Szene(); // Verarbeitet die Zustände für die LEDs
        BeleuchtungAktiv(1);
      }
      else // Beleuchtung aus
      {
        LedsAusschalten(); // Alles Aus
        BeleuchtungAktiv(0);
      }
      break;
    case 1: // LED Test weiss
      for (i = 0; i < AnzahlWS2812Benutzt; i++) // Für jede LED
      {
        stripWS2812.setPixelColor(i, 255, 255, 255); // weiss
      }
      stripWS2812.show();
      for (i = 0; i < AnzahlPL9823Benutzt; i++) // Für jede LED
      {
        stripPL9823.setPixelColor(i, 255, 255, 255); // weiss
      }
      stripPL9823.show();
      BeleuchtungAktiv(1);
      break;
    case 2: // LED Test rot
      for (i = 0; i < AnzahlWS2812Benutzt; i++) // Für jede LED
      {
        stripWS2812.setPixelColor(i, 255, 0, 0); // rot
      }
      stripWS2812.show();
      for (i = 0; i < AnzahlPL9823Benutzt; i++) // Für jede LED
      {
        stripPL9823.setPixelColor(i, 255, 0, 0); // rot
      }
      stripPL9823.show();
      BeleuchtungAktiv(1);
      break;
    case 3: // LED Test grün
      for (i = 0; i < AnzahlWS2812Benutzt; i++) // Für jede LED
      {
        stripWS2812.setPixelColor(i, 0, 255, 0); // grün
      }
      stripWS2812.show();
      for (i = 0; i < AnzahlPL9823Benutzt; i++) // Für jede LED
      {
        stripPL9823.setPixelColor(i, 0, 255, 0); // grün
      }
      stripPL9823.show();
      BeleuchtungAktiv(1);
      break;
    case 4: // LED Test blau
      for (i = 0; i < AnzahlWS2812Benutzt; i++) // Für jede LED
      {
        stripWS2812.setPixelColor(i, 0, 0, 255); // blau
      }

      stripWS2812.show();
      for (i = 0; i < AnzahlPL9823Benutzt; i++) // Für jede LED
      {
        stripPL9823.setPixelColor(i, 0, 0, 255); // blau
      }
      stripPL9823.show();
      BeleuchtungAktiv(1);
      break;

    default:
      break;
    }
    // delay(30); ???

    // Periode = millis() - lastMillis1; // ???
    // Serial.println(Periode); // ???
    // Serial.println(millis()); // ???
    // Serial.println(lastMillis1); // ???
    // Serial.println(); // ???
  }
} // loop